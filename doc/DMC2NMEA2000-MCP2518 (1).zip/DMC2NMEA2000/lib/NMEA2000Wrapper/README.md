# NMEA2000Wrapper
Stilsoep wrapper around the NMEA2000 library
