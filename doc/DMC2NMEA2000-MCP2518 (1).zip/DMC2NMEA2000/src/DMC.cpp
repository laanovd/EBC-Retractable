/*********************************************************************
 *    DMC.ino
 *    
 *    Data handeling for Direct Motor Control (DMC)
 * 
 ********************************************************************/
#include <Arduino.h>
#include <ArduinoJson.h>
#include <endian.h>
#include "WebServer.h"

#include "Debug.h"
#include "Config.h"

#include "Storage.h"
#include "MCPCom.h"
#include "CLI.h"
#include "NMEA.h"
#include "DMC.h"

/*********************************************************************
 * Constants
 ********************************************************************/
#undef DEBUG_FRAMES // Debugging to Serial

#define DEFAULT_INSTANCE 0

/*********************************************************************
 * POD motor definitions
 ********************************************************************/
typedef struct {
  const String id;   // Motor ID
  const String pod;  // POD indication
  const int rpm;     // Maximum RPM
} motor_t;

// DMC motor types
const motor_t MOTOR_TYPES[] = {
  { "M086", "POD 3.0",  4000 },
  { "M133", "POD 5.0",  2500 },
  { "M212", "POD 11.0", 1500 },
  { "M212", "POD 15.0", 1700 },
  { "M341", "POD 30.0", 1000 }
};

#define MAX_MOTOR_TYPES (sizeof(MOTOR_TYPES) / sizeof(motor_t))

/*********************************************************************
 *  Type definitions
 *   
 ********************************************************************/
// DMC data structure
typedef struct dmc_data_t {
  uint16_t _motor_speed;            // 0..4096 (???)
  int16_t _motor_current;           // -32768 .. 32768  [0,1 Amp]
  uint8_t _motor_voltage;           // 0..255 V
  uint8_t _battery_voltage;         // 0..255 V
  int16_t _battery_current;         // -32768 .. 32768  [0,1 Amp]
  int16_t _actual_torque;           // -32768 .. 32768  [100/4096]
  int16_t _actual_speed;            // -32768 .. 32768  [100/4096]
  uint8_t _drive_status_indicator;  // see Table 1  code 0..10
                                    // or Speed_Limit_Indicator
  uint8_t _torque_limit_indicator;  // or Motor_limit_indicator
  uint8_t _fault_code;              // bit 0 Toggle_Security_Bit when in Canbus drive control Mode
                                    // bit 1 Ready to close Line Contactor
                                    // bit 2 Controller is Auto Tuning
                                    // bit 3 Controller Is Pulsing
                                    // bit 4 Status Dig. Out 4 (Configurable-Remote Led-)
                                    // bit 5 Status Dig. Out 3 (Power Steer )
                                    // bit 6 Status Dig. Out 2 (E-Magnet Brake)
                                    // bit 7 Status Dig. Out 1 Line contactor
  uint8_t _controller_temperature;  // 0..255 Gr Celsius
  uint8_t _motor_temperature;       // 0..255 Gr Celsius
  uint8_t _bdi;                     // 0..100 %
  uint16_t _fault_subcode;          // 0..65535  Number
  uint16_t _throttle;               // 0..4096 (0..100%)    [100/4096]
  uint16_t _brake_pedal;            // 0..4096 (0..100%)    [100/4096]
  int16_t _ad3;                     // -4096...4096  (-100%..100%) [100/4096]
  uint8_t _digital_inputs;          // Bit 0 Input1 Forward direction (Pump Pot / Switch 1 )
                                    // Bit 1 Input2 Reverse direction (Pump Switch 2)
                                    // Bit 2 Input3 FootSwitch (Pump Switch 3)
                                    // Bit 3 Input4 Seat/Enable (Pump Switch 4)
                                    // Bit 4 input5 Speed Lim.1 (Pump Switch 5)
                                    // Bit 5 Input6 Speed Lim. 2 (Pump Switch 6)
                                    // Bit 6 Input7 Handbrake / Speed Lim. 3 (Pump Inhibit)
                                    // Bit 7 not used
} dmc_data_t;

/*********************************************************************
 * Global data
 *   
 ********************************************************************/
static dmc_data_t dmc_data[1];

static int dmc_frames_received = 0;
static int dmc_frames_processed = 0;
static int dmc_error_delay = 0;

static int dmc_motor_type = 0;

/********************************************************************
 * DMC frames received
 *******************************************************************/
bool DMC_data_received(void) {
  static int memo = 0;
  if (memo < dmc_frames_received) {
    memo = dmc_frames_received;
    return true;
  }
  return false;
}

/********************************************************************
 * DMC error status
 *******************************************************************/
bool DMC_error(void) {
  return (dmc_error_delay == 0);
}

/********************************************************************
 * DMC frame received
 *******************************************************************/
static void DMC_frame_received(void) {
  /* Increment received frame counter */
  dmc_frames_received++;

  /* Reload error countdown */
  dmc_error_delay = ERROR_DELAY_PRELOAD;
}

/*********************************************************************
 * Check valid motor type
 *  - 0 is invalid motor type.
 ********************************************************************/
static bool is_valid_motor_type(int mode) {
  return ((mode >= 1) && (mode <= MAX_MOTOR_TYPES));
}

/*********************************************************************
 *  Read motor type
 *  - 0 is invalid motor type.
 ********************************************************************/
static int get_motor_type(void) {
  if (!is_valid_motor_type(dmc_motor_type)) {
    return 0;
  }

  return dmc_motor_type;
}

/*********************************************************************
 *  Read motor type as string
 *  - 0 is invalid motor type.
 ********************************************************************/
String get_motor_type_string(void) {
  int motor_type = get_motor_type();

  if (!is_valid_motor_type(motor_type)) {
    return "<unknown>";
  }

  return MOTOR_TYPES[motor_type - 1].pod;
}

/*********************************************************************
 *  Set motor type
 *  - 0 is invalid motor type.
 ********************************************************************/
static void set_motor_type(int motor_type) {
  if (!is_valid_motor_type(motor_type)) {
    return;
  }

  if (dmc_motor_type != motor_type) {
    dmc_motor_type = motor_type;
    STORAGE_set_int(JSON_DMC_MOTOR_TYPE, dmc_motor_type);
  }
}

/*********************************************************************
 * Get maximum RPM
 * - 0 is a invalid motor type
 ********************************************************************/
int GetDMCMaxRPM(void) {
  int motor_type = get_motor_type();
  if ((motor_type < 1) || (motor_type > MAX_MOTOR_TYPES))
    return 0;

  return MOTOR_TYPES[motor_type - 1].rpm;
}

/*********************************************************************
 *  Get motor speed (double, RPM)
 *  - motor speed from DMC as rpm (0 .. MAX-RPM-FROM-MOTOR)
 ********************************************************************/
double GetDMCMotorSpeed(void) 
{
  return (double)dmc_data[DEFAULT_INSTANCE]._motor_speed;
};

/*********************************************************************
 *  Get motor current (uint16 0 .. 3276.8 Amp)
 ********************************************************************/
uint16_t GetDMCMotorCurrent(void)  // -32768 .. 32768  [0,1 Amp]
{
  return dmc_data[DEFAULT_INSTANCE]._motor_current / 10;
}

/*********************************************************************
 * Get motor voltage (uint8, 0 .. 255 Volt)
 ********************************************************************/
uint8_t GetDMCMotorVoltage(void)  // 0..255 V
{
  return dmc_data[DEFAULT_INSTANCE]._motor_voltage;
}

/*********************************************************************
 * Get battery voltage (double, 0.0 .. 255.0 Volt)
 ********************************************************************/
double GetDMCBatteryVoltage(void)  // 0..255 V
{
  return (double)dmc_data[DEFAULT_INSTANCE]._battery_voltage;
}

/*********************************************************************
 * Get battery current (double, 0.0 .. 3276.8 Amp)
 ********************************************************************/
double GetDMCBatteryCurrent(void)  // -32768 .. 32768  [0,1 Amp]
{
  return (double)dmc_data[DEFAULT_INSTANCE]._battery_current / 10.0;
}

/*********************************************************************
 * Get actual torque (uint16, 0 .. 100 %)
 ********************************************************************/
uint16_t GetDMCActualTorque(void)  // -32768 .. 32768  [100/4095]
{
  return int((dmc_data[DEFAULT_INSTANCE]._actual_torque * 100) / 4096);  // actual torque in % van maximale instelling NMEA2000 display
}

/*********************************************************************
 * Get actual speed (uint16, 0 .. 100 %)
 ********************************************************************/
uint16_t GetDMCActualSpeed(void)  // -32768 .. 32768  [100/4095]
{
  return int((dmc_data[DEFAULT_INSTANCE]._actual_speed * 100) / 4096);  // actual speed in % van maximale instelling NMEA2000 display
}

/*********************************************************************
 * Get drive status
 ********************************************************************/
uint8_t GetDMCDriveStatusIndicator(void)  // see Table 1  code 0..16
{
  return dmc_data[DEFAULT_INSTANCE]._drive_status_indicator;
}

/*********************************************************************
 * Get torque limit
 ********************************************************************/
uint8_t GetDMCTorqueLimitIndicator(void)  // See table 2, code 0..16
{
  return dmc_data[DEFAULT_INSTANCE]._torque_limit_indicator;
}

/*********************************************************************
 * Get DMC fault code
 *
 * unit8_t _fault_code:
 *  bit 0 Toggle_Security_Bit when in Canbus drive control Mode
 *  bit 1 Ready to close Line Contactor
 *  bit 2 Controller is Auto Tuning
 *  bit 3 Controller Is Pulsing
 *  bit 4 Status Dig. Out 4 (Configurable-Remote Led-)
 *  bit 5 Status Dig. Out 3 (Power Steer )
 *  bit 6 Status Dig. Out 2 (E-Magnet Brake)
 *  bit 7 Status Dig. Out 1 Line contactor
 ********************************************************************/
uint8_t GetDMCFaultCode(void)  // ...
{
  return dmc_data[DEFAULT_INSTANCE]._fault_code;
}

/*********************************************************************
 * Get DMC fault sub code
 ********************************************************************/
uint16_t GetDMCFaultSubCode(void)  // 0..65535  Number
{
  return dmc_data[DEFAULT_INSTANCE]._fault_subcode;
}

/*********************************************************************
 * Get controller temperature
 ********************************************************************/
double GetDMCControllerTemperature(void)  // 0..255 ~ -50..223 Gr Celsius
{
  return ((double)dmc_data[DEFAULT_INSTANCE]._controller_temperature - 50.0) + 273.16;
}

/*********************************************************************
 * Get motor temperature (+50, +273.16 voor K)
 ********************************************************************/
double GetDMCMotorTemperature(void)  // 0..255 ~ -50..223 Gr Celsius
{
  return ((double)dmc_data[DEFAULT_INSTANCE]._motor_temperature - 50.0) + 273.16;
}

/*********************************************************************
 * Get BDI (0..100%)
 ********************************************************************/
uint8_t GetDMCBDI(void)  // 0..100 %
{
  return dmc_data[DEFAULT_INSTANCE]._bdi;
}

/*********************************************************************
 * Get throttle
 ********************************************************************/
uint16_t GetDMCThrottle(void)  // 0..4096 (0..100%)    [100/4096]
{
  return uint16_t(((int)dmc_data[DEFAULT_INSTANCE]._throttle * 100) / 4096);  // actual throttle in % van maximale instelling NMEA2000 display
}

/*********************************************************************
 * Get break pedal
 ********************************************************************/
uint16_t GetDMCBreakPedal(void)  // 0..4096 (0..100%)    [100/4095]
{
  return uint16_t(((int)dmc_data[DEFAULT_INSTANCE]._brake_pedal * 100) / 4096);  // actual Brake Pedal in % van maximale instelling NMEA2000 display

}

/*********************************************************************
 * Get AD3 (-100%..+100%)
 ********************************************************************/
int GetDMCAD3(void)  // -4096...4096  (-100%..100%) [100/4095]
{
  return (int)((dmc_data[DEFAULT_INSTANCE]._ad3 * 100) / 4096);
}

/*********************************************************************
 *  Get digital inputs status
 *
 * unit8_t _digital_inputs:   
 *  Bit 0 Input1 Forward direction (Pump Pot / Switch 1 )
 *  Bit 1 Input2 Reverse direction (Pump Switch 2)
 *  Bit 2 Input3 FootSwitch (Pump Switch 3)
 *  Bit 3 Input4 Seat/Enable (Pump Switch 4)
 *  Bit 4 input5 Speed Lim.1 (Pump Switch 5)
 *  Bit 5 Input6 Speed Lim. 2 (Pump Switch 6)
 *  Bit 6 Input7 Handbrake / Speed Lim. 3 (Pump Inhibit)
 *  Bit 7 not used
 ********************************************************************/
uint8_t GetDMCDigitalInputs(void)  // ...
{
  return dmc_data[DEFAULT_INSTANCE]._digital_inputs;
}

/*********************************************************************
 *  DMC process frame with id=0x13x
 *   
 ********************************************************************/
static String DMC_frame_13x_to_string(void) {
  char msg[128];
  snprintf(msg, sizeof(msg), "Speed %3.0f rpm, voltage: %d, current: %d. Battery: voltage: %3.1f, current: %3.1f.",
          GetDMCMotorSpeed(),
          (int)GetDMCMotorVoltage(),
          (int)GetDMCMotorCurrent(),
          GetDMCBatteryVoltage(),
          GetDMCBatteryCurrent());
  return msg;
}

void DMC_process_frame_13x(uint8_t *buffer, uint8_t size) {
  struct data_fmt {
    uint16_t Motor_Speed;     // 0..65535 [RPM]
    int16_t Motor_Current;    // -32768 .. 32768  [0,1 Amp]
    uint8_t Motor_Voltage;    // 0..255 V
    uint8_t Battery_Voltage;  // 0..255 V
    int16_t Battery_Current;  // -32768 .. 32768  [0,1 Amp]
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  dmc_data[DEFAULT_INSTANCE]._motor_speed = bswap16(ptr->Motor_Speed);
  dmc_data[DEFAULT_INSTANCE]._motor_current = bswap16(ptr->Motor_Current);
  dmc_data[DEFAULT_INSTANCE]._motor_voltage = ptr->Motor_Voltage;
  dmc_data[DEFAULT_INSTANCE]._battery_voltage = ptr->Battery_Voltage;
  dmc_data[DEFAULT_INSTANCE]._battery_current = bswap16(ptr->Battery_Current);

#ifdef DEBUG_FRAMES
  Serial.println("DMC frame 0x13x received.");
#endif

  String txt = "0x13x-Motor: " + DMC_frame_13x_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  DMC process frame with id=0x14x
 *   
 ********************************************************************/
static String DMC_frame_14x_to_string(void) {
  char msg[128];
  snprintf(msg, sizeof(msg), "Torque %d, actual speed: %d, drive-status: %d torque-limit: %d, fault-code: %d.",
           GetDMCActualTorque(), 
           GetDMCActualSpeed(), 
           GetDMCDriveStatusIndicator(),
           GetDMCTorqueLimitIndicator(), 
           (int)GetDMCFaultCode());
  return msg;
}

void DMC_process_frame_14x(uint8_t *buffer, uint8_t size) {
  struct data_fmt {
    int16_t Actual_Torque;           // -32768 .. 32768  [100/4096]
    int16_t Actual_Speed;            // -32768 .. 32768  [100/4096]
    uint8_t Drive_status_indicator;  // see Table 1  code 0..10
    uint8_t Torque_limit_indicator;  // or Motor_limit_indicator
    uint8_t Fault_Code;              // bit 0 ~ 7
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  dmc_data[DEFAULT_INSTANCE]._actual_torque = bswap16(ptr->Actual_Torque);
  dmc_data[DEFAULT_INSTANCE]._actual_speed = bswap16(ptr->Actual_Speed);
  dmc_data[DEFAULT_INSTANCE]._drive_status_indicator = ptr->Drive_status_indicator;
  dmc_data[DEFAULT_INSTANCE]._torque_limit_indicator = ptr->Torque_limit_indicator;
  dmc_data[DEFAULT_INSTANCE]._fault_code = ptr->Fault_Code;

#ifdef DEBUG_FRAMES
  Serial.println("DMC frame 0x14x received.");
#endif

  String txt = "0x14x-Motor: " + DMC_frame_14x_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  DMC process frame with id=0x15x
 *   
 ********************************************************************/
static String DMC_frame_15x_to_string(void) {
  char msg[128];
  snprintf(msg, sizeof(msg), "Controller temp.: %3.1f, motor temp.: %3.1f, BDI: %d fault-subcode: %d.",
           GetDMCControllerTemperature() - 273.16,
           GetDMCMotorTemperature() - 273.16, 
           (int)GetDMCBDI(), 
           GetDMCFaultSubCode());
  return msg;
}

void DMC_process_frame_15x(uint8_t *buffer, uint8_t size) {
  struct data_fmt {
    uint8_t Controller_Temperature;  // 0..255 Gr Celsius
    uint8_t Motor_Temperature;       // 0..255 Gr Celsius
    uint8_t BDI;                     // 0..100 %
    uint16_t Fault_subcode;          // 0..65535  Number
    uint8_t not_used_1;
    uint8_t not_used_2;
    uint8_t not_used_3;
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  dmc_data[DEFAULT_INSTANCE]._controller_temperature = ptr->Controller_Temperature;
  dmc_data[DEFAULT_INSTANCE]._motor_temperature = ptr->Motor_Temperature;
  dmc_data[DEFAULT_INSTANCE]._bdi = ptr->BDI;
  dmc_data[DEFAULT_INSTANCE]._fault_subcode = bswap16(ptr->Fault_subcode);

#ifdef DEBUG_FRAMES
  Serial.println("DMC frame 0x15x received.");
#endif

  String txt = "0x15x-Motor: " + DMC_frame_15x_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  DMC process frame with id=0x19x
 *   
 ********************************************************************/
static String DMC_frame_19x_to_string() {
  char msg[128];
  snprintf(msg, sizeof(msg), "Throttle: %d, break-pedal: %d, AD3: %d digital-inputs: %04x.",
           GetDMCThrottle(), 
           GetDMCBreakPedal(), 
           GetDMCAD3(), 
           GetDMCDigitalInputs());
  return msg;
}

void DMC_process_frame_19x(uint8_t *buffer, uint8_t size) {
  struct data_fmt {
    uint16_t Throttle;       // 0..4096 (0..100%)    [100/4096]
    uint16_t Brake_Pedal;    // 0..4096 (0..100%)    [100/4096]
    int16_t AD3;             // -4096...4096  (-100%..100%) [100/4096]
    uint8_t Digital_Inputs;  // Bit 0 ~ 7
    uint8_t not_used_4;
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  dmc_data[DEFAULT_INSTANCE]._throttle = bswap16(ptr->Throttle);
  dmc_data[DEFAULT_INSTANCE]._brake_pedal = bswap16(ptr->Brake_Pedal);
  dmc_data[DEFAULT_INSTANCE]._ad3 = bswap16(ptr->AD3);
  dmc_data[DEFAULT_INSTANCE]._digital_inputs = ptr->Digital_Inputs;

#ifdef DEBUG_FRAMES
  Serial.println("DMC frame 0x19x received.");
#endif

  String txt = "0x19x-Motor: " + DMC_frame_19x_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  DMC process received frames
 *   
 ********************************************************************/
void DMC_process_frame(uint32_t id, uint8_t *buffer, uint8_t size, bool rtr, bool ext) {
  int motor_type = 0;
  (void) ext;

  DMC_frame_received();

#ifdef DEBUG_FRAMES
  Serial.printf("DMC receive-calback with frame with id %d.\r\n", id);
#endif

  // Extract motor type for Direct Motor Control (DMC)
  if (((id >= 0x130) && (id <= 0x15F)) || ((id >= 0x190) && (id <= 0x19F))) {
    motor_type = (id & 0x000F);
  }

  set_motor_type(motor_type);

  dmc_frames_processed++;

  switch (id & 0xFFF0) {
    case 0x130:
      DMC_process_frame_13x(buffer, size);
      break;

    case 0x140:
      DMC_process_frame_14x(buffer, size);
      break;

    case 0x150:
      DMC_process_frame_15x(buffer, size);
      break;

    case 0x190:
      DMC_process_frame_19x(buffer, size);
      break;

    default:
#ifdef DEBUG_FRAMES
      Serial.println("DMC_process_frame: unknow id received, no action.");
#endif
      break;
  }
}

/*******************************************************************
 * Debug Dynamic Motor Control
 *******************************************************************/
static void DMC_debug_data(void) {
  DEBUG_data("\r\nDMC: " + DMC_frame_13x_to_string());
  DEBUG_data(DMC_frame_14x_to_string());
  DEBUG_data(DMC_frame_15x_to_string());
  DEBUG_data(DMC_frame_19x_to_string());
}

/*********************************************************************
 * Create initial JSON data
 ********************************************************************/
static JsonDocument DMC_json(void) {
  JsonDocument doc;

  doc[JSON_DMC_CHANNEL] = "MCP";
  doc[JSON_DMC_RECEIVED] = dmc_frames_received;

  return doc;
}

/*********************************************************************
 * Create string
 ********************************************************************/
String DMC_string(void) {
  JsonDocument doc = DMC_json();

  String text = "--- DMC ---";

  text.concat("\r\nDMC communication channel: ");
  text.concat(doc[JSON_DMC_CHANNEL].as<const char *>());

  text.concat("\r\nDMC frames received: ");
  text.concat(doc[JSON_DMC_RECEIVED].as<int>());

  // TODO: Battery data

  text.concat("\r\n");
  return text;
}

/*********************************************************************
 *  CLI: List storage content
 ********************************************************************/
static void clicb_list_dmc(cmd *c) {
  (void)c;
  CLI_println(DMC_string());
}

/*********************************************************************
 *  Setup storage command handlers
 ********************************************************************/
void DMC_cli_handlers(void) {
  cli.addCommand("dmc", clicb_list_dmc);
}

/*********************************************************************
 * REST API: read handler
 *********************************************************************/
void DMC_rest_read(AsyncWebServerRequest *request) {
  String str;
  serializeJson(DMC_json(), str);
  request->send(200, "application/json", str.c_str());
}

static rest_api_t DMC_api_handlers = {
    /* uri */ "/api/v1/dmc",
    /* comment */ "DMC module",
    /* instances */ 1,
    /* fn_create */ nullptr,
    /* fn_read */ DMC_rest_read,
    /* fn_update */ nullptr,
    /* fn_delete */ nullptr,
};

/********************************************************************************
 *  DMC monitor task
 ********************************************************************************/
void DMC_monitor_task(void *parameter) {
  (void)parameter;

  while (1) {
    vTaskDelay(1000 / portTICK_PERIOD_MS);

    if (dmc_error_delay > 0)
      dmc_error_delay--;
  }
}

/********************************************************************************
 * DMC debug task
 ********************************************************************************/
void DMC_debug_task(void *parameter) {
  (void)parameter;

  while (1) {
    vTaskDelay(3000 / portTICK_PERIOD_MS);

    if (DEBUG_data_active())
      DMC_debug_data();
  }
}

/********************************************************************************
 *  Setup BMS tasks
 *   
 ********************************************************************************/
static void DMC_setup_tasks() {
  xTaskCreate(DMC_monitor_task, "DMC monitor task", 1024, NULL, 10, NULL);
  xTaskCreate(DMC_debug_task, "DMC debug task", 2048, NULL, 15, NULL);
}

/*********************************************************************
 * Setup MCP receive handler
 ********************************************************************/
static void DMC_setup_CAN(void) {
  MCP1_rx_handler(DMC_process_frame);
}

/********************************************************************
 * DMC Setup variables
 ********************************************************************/
void DMC_setup_variables(void) {
  /* DMC motor type */
  if (STORAGE_get_int(JSON_DMC_MOTOR_TYPE, dmc_motor_type)) {
    dmc_motor_type = 0;
    STORAGE_set_int(JSON_DMC_MOTOR_TYPE, dmc_motor_type);
  }
}

/*********************************************************************
 * DMC setup
 ********************************************************************/
void DMC_setup(void) {
  DMC_setup_variables(); 
  DMC_cli_handlers();
  setup_uri(&DMC_api_handlers);
}

/*********************************************************************
 * DMC start
 ********************************************************************/
void DMC_start(bool active) {
  if (active) {
    Serial.println("DMC mode active.");

    MCP1_setup(CAN_250KB);
    DMC_setup_CAN();

    DMC_setup_tasks();
  }

#ifdef DEBUG_FRAMES
  Serial.println("DMC debug frames activated...");
#endif

  Serial.println("DMC setup completed.");
}
