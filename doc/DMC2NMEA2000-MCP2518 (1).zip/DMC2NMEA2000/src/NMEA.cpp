// RIM-N2k-monitor
#include <Arduino.h>
#include <ArduinoJson.h>
#include <Math.h>

#define USE_N2K_CAN USE_N2K_ESP32_CAN
#define ESP32_CAN_TX_PIN GPIO_NUM_5  // If you use ESP32 and do not have TX on default IO 16, uncomment this and and modify definition to match your CAN TX pin.
#define ESP32_CAN_RX_PIN GPIO_NUM_4  // If you use ESP32 and do not have RX on default IO 4, uncomment this and and modify definition to match your CAN TX pin.
#include <N2kMessages.h>
#include <NMEA2000_CAN.h>  // This will automatically choose right CAN library and create suitable NMEA2000 object

#include "BMS.h"
#include "CLI.h"
#include "Config.h"
#include "DMC.h"
#include "Debug.h"
#include "NMEA.h"
#include "Storage.h"
#include "VED.h"
#include "WebServer.h"
#include "WiFiCom.h"

/*********************************************************************
 * Constanten
 ********************************************************************/
const char* NMEA_MODE_NAMES[] = {"UNKNOWN", "BMS", "DMC", "SHUNT"};

// Define schedulers for messages. Define schedulers here disabled. Schedulers will be enabled
// on OnN2kOpen so they will be synchronized with system.
// We use own scheduler for each message so that each can have different offset and period.
// Setup periods according PGN definition (see comments on IsDefaultSingleFrameMessage and
// IsDefaultFastPacketMessage) and message first start offsets. Use a bit different offset for
// each message so they will not be sent at same time.
tN2kSyncScheduler HeartbeatScheduler(false, 1000, 0);
tN2kSyncScheduler AddressCheckScheduler(false, 60000, 0);    // 1 min.
tN2kSyncScheduler EngineRapidScheduler(false, 1000, 100);    // 1sec.
tN2kSyncScheduler EngineDynamicScheduler(false, 1000, 100);  // 5sec.
tN2kSyncScheduler DCBatStatusScheduler(false, 1500, 500);    // 1.5sec.
tN2kSyncScheduler DCStatusScheduler(false, 1500, 510);       // 1.5sec.
tN2kSyncScheduler BatConfScheduler(false, 5000, 520);        // 5sec.

/*********************************************************************
 * Globals
 ********************************************************************/
// List here messages your device will transmit.
const unsigned long TransmitMessages_GATEWAY[] PROGMEM = {127488L, 127489L, 0L};
const unsigned long TransmitMessages_BATTERY[] PROGMEM = {127506L, 127508L, 127513L, 0L};

tNMEA2000& NMEA2000x = *(new tNMEA2000_esp32());

static int nmea_frame_transmitted = 0;
static int nmea_instance = 1;
static int nmea_address = 23;
static int nmea_operational_mode = 0;
static String nmea_name = "";

String OperationalModeStr(int mode);

/*********************************************************************
 * Create initial JSON data
 ********************************************************************/
static JsonDocument NMEA_json(void) {
  JsonDocument doc;

  doc[JSON_NMEA_MODE] = OperationalModeStr(nmea_operational_mode);

  doc[JSON_NMEA_INSTANCE] = nmea_instance;
  doc[JSON_NMEA_ADDRESS] = nmea_address;

  return doc;
}

/*********************************************************************
 * Create NMEA string
 ********************************************************************/
String NMEA_string(void) {
  JsonDocument doc = NMEA_json();

  String text = "--- NMEA ---";

  text.concat("\r\nOperational mode: ");
  text.concat(doc[JSON_NMEA_MODE].as<const char*>());

  text.concat("\r\nNMEA2000 instance: ");
  text.concat(doc[JSON_NMEA_INSTANCE].as<int>());
  text.concat(", NMEA2000 bus address: ");
  text.concat(doc[JSON_NMEA_ADDRESS].as<int>());

  text.concat("\r\n");
  return text;
}

/*********************************************************************
 * Get NMEA2000 instance
 ********************************************************************/
int get_nmea_instance(void) {
  return nmea_instance;
}

/*********************************************************************
 * Get NMEA2000 communication address
 ********************************************************************/
int get_nmea_address(void) {
  return nmea_address;
}

/*********************************************************************
 * Get NMEA2000 communication address
 ********************************************************************/
static void set_nmea_address(int address) {
  if (nmea_address != address) {
    nmea_address = address;
    STORAGE_set_int(JSON_NMEA_ADDRESS, nmea_address);
  }
}

/*********************************************************************
 * Validate oprational mode
 ********************************************************************/
static bool is_valid_operational_mode(int mode) {
  return ((mode >= NMEA_MODE_BMS) && (mode <= NMEA_MODE_MAX));
}

/*********************************************************************
 * Operational mode to string
 ********************************************************************/
String OperationalModeStr(int mode) {
  if (!is_valid_operational_mode(mode)) {
    return NMEA_MODE_NAMES[NMEA_MODE_UNKNOWN];
  }

  return NMEA_MODE_NAMES[mode];
}

/*********************************************************************
 *  Read device name
 ********************************************************************/
String get_nmea_name(void) {
  return nmea_name;
}

/*********************************************************************
 *  Set device name
 ********************************************************************/
static void set_nmea_name(String id) {
  nmea_name = id;
  STORAGE_set_string(JSON_NMEA_NAME, nmea_name);
}

/*********************************************************************
 * Make an initial devcice name
 ********************************************************************/
static String make_nmea_name(void) {
  char name[64];
  int instance = get_nmea_instance();
  String motor_type_str, id = ChipIds();

  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      snprintf(name, sizeof(name), "BMS-%d-%s", instance, id);
      break;

    case NMEA_MODE_DMC:
      motor_type_str = get_motor_type_string();
      snprintf(name, sizeof(name), "%s-%d-%s", motor_type_str.c_str(), instance, id);
      break;

    case NMEA_MODE_SHUNT:
      snprintf(name, sizeof(name), "SHT-%d-%s", instance, id);
      break;

    default:
      snprintf(name, sizeof(name), "UNK-%d-%s", instance, id);
      break;
  }

  return String(name);
}

/*********************************************************************
 * Read operational mode (BMS/DMC/SHUNT/UNKNOWN)
 ********************************************************************/
int get_operational_mode(void) {
  return nmea_operational_mode;
}

/*********************************************************************
 * Set operational mode (BMS/DMC/SHUNT/UNKNOWN)
 ********************************************************************/
void set_operational_mode(int mode) {
  if (is_valid_operational_mode(mode)) {
    if (nmea_operational_mode != mode) {
      // Set operational mode
      nmea_operational_mode = mode;
      STORAGE_set_int(JSON_NMEA_MODE, nmea_operational_mode);

      // Set NMEA2000 name
      set_nmea_name(make_nmea_name());
    }
  }
}


/*******************************************************************
 * Get Battery remaining capacity (Ah)
 *******************************************************************/
static double GetBatteryRemainingCapacity(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryRemainingCapacity();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryRemainingCapacity();
    default:
      break;
  }
  return 0.0;
}

/*******************************************************************
 *  Getter battery voltage (V)
 *******************************************************************/
static double GetBatteryVoltage(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryVoltage();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryVoltage();
    default:
      break;
  }
  return 0.0;
}

/*******************************************************************
 *  Getter Battery ampere (A)
 *******************************************************************/
static double GetBatteryCurrent(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryCurrent();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryCurrent();
    default:
      break;
  }
  return 0.0;
}

/*******************************************************************
 *  Getter Battery pack temperature (K)
 *******************************************************************/
static double GetBatteryPackTemperature(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryPackTemperature();
    case NMEA_MODE_SHUNT:
      return 273.16;
    default:
      break;
  }
  return 273.16;
}

/*******************************************************************
 *  Getter Battery State Of Charge (%)
 *******************************************************************/
static uint8_t GetBatteryStateOfCharge(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return (uint8_t)GetBMSBatteryStateOfCharge();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryStateOfCharge();
    default:
      break;
  }
  return 0;
}

/*******************************************************************
 *  Getter Battery remaining time (s)
 *******************************************************************/
static double GetBatteryRemainingTime(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryRemainingTime();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryRemainingTime();
    default:
      break;
  }
  return 0.0;
}

/*******************************************************************
 * Get shunt discharged energy (kW)
 *******************************************************************/
static double GetBatteryFullCapacity(void) {
  switch (get_operational_mode()) {
    case NMEA_MODE_BMS:
      return GetBMSBatteryFullCapacity();
    case NMEA_MODE_SHUNT:
      return GetSHTBatteryFullCapacity();
    default:
      break;
  }
  return 0.0;
}

/*******************************************************************
  Fault and subcode to flags
 *******************************************************************/
static void FaultToNMEAFlag(int code, int subcode, tN2kEngineDiscreteStatus1* Status1, tN2kEngineDiscreteStatus2* Status2) {
  *Status1 = *Status2 = 0;

  switch (code) {
    case 1:
    case 3:
    case 4:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 14:
    case 15:
    case 16:
    case 18:
    case 19:
      Status1->Bits.CheckEngine = 1;
      break;
    case 13:
      Status2->Bits.NeutralStartProtect = 1;
      break;
    case 5:
    case 6:
    case 26:
    case 36:
      Status1->Bits.OverTemperature = 1;
      break;
    case 2:
    case 17:
      Status1->Bits.LowSystemVoltage = 1;
      break;
    case 30:
      Status1->Bits.RevLimitExceeded = 1;
      break;
    case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 27:
      Status2->Bits.WarningLevel1 = 1;
      break;
    case 32:
    case 33:
    case 34:
    case 37:
    case 38:
    case 39:
    case 40:
      Status2->Bits.WarningLevel2 = 1;
      break;
    case 28:
      switch (subcode) {
        case 1:
        case 2:
        case 3:
        case 4:
          Status2->Bits.SubOrSecondaryThrottle = 1;
          break;
        case 5:
          Status2->Bits.EngineCommError = 1;
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}

// *****************************************************************************
// Call back for NMEA2000 open. This will be called, when library starts bus communication.
// See NMEA2000.SetOnOpen(OnN2kOpen); on setup()
void OnN2kOpen() {
  int mode = get_operational_mode();

  // Start schedulers now.
  HeartbeatScheduler.UpdateNextTime();
  AddressCheckScheduler.UpdateNextTime();

  if (mode == NMEA_MODE_DMC) {
    EngineRapidScheduler.UpdateNextTime();
    EngineDynamicScheduler.UpdateNextTime();
  }

  if ((mode == NMEA_MODE_BMS) || (mode == NMEA_MODE_SHUNT)) {
    DCBatStatusScheduler.UpdateNextTime();
    DCStatusScheduler.UpdateNextTime();
    BatConfScheduler.UpdateNextTime();
  }
}

/********************************************************************
 * Setup NMEA2000
 ********************************************************************/
static void NMEA2000_setup_DMC() {
  int chip_id = ChipId();
  String id = get_nmea_name() + " ";
  char name[32];

  Serial.println(F("NMEA2000 setup DMC."));

  snprintf(name, sizeof(name), "DMC%x07", chip_id);
  NMEA2000.SetProductInformation(name,         // Manufacturer's Model serial code
                                 100,          // Manufacturer's product code
                                 id.c_str(),   // Manufacturer's Model ID
                                 "1.0.0.1 ",   // Manufacturer's Software version code
                                 "1.0.0.0 ");  // Manufacturer's Model version

  // Set device information
  NMEA2000.SetDeviceInformation(chip_id,  // Unique number. Use e.g. Serial number.
                                140,      // Device function=Engine.
                                50,       // Device class=Propulsion.
                                2040);    // Just choosen free from code list on https://web.archive.org/web/20190529161431/http://www.nmea.org/Assets/20121020%20nmea%202000%20registration%20list.pdf

  // Here we tell library, which PGNs we transmit
  NMEA2000.ExtendTransmitMessages(TransmitMessages_GATEWAY);
}

static void NMEA2000_setup_BMS() {
  int chip_id = ChipId();
  String id = get_nmea_name() + " ";
  char name[32];

  Serial.println(F("NMEA2000 setup BMS."));

  snprintf(name, sizeof(name), "BMS%x07", chip_id);
  NMEA2000.SetProductInformation(name,         // Manufacturer's Model serial code
                                 101,          // Manufacturer's product code
                                 id.c_str(),   // Manufacturer's Model ID
                                 "1.0.0.1 ",   // Manufacturer's Software version code
                                 "1.1.0.0 ");  // Manufacturer's Model version

  // Set device information
  NMEA2000.SetDeviceInformation(chip_id,  // Unique number. Use e.g. Serial number.
                                170,      // Device function=Temperature. See codes on https://web.archive.org/web/20190531120557/https://www.nmea.org/Assets/20120726%20nmea%202000%20class%20&%20function%20codes%20v%202.00.pdf
                                35,       // Device class=Sensor Communication Interface. See codes on https://web.archive.org/web/20190531120557/https://www.nmea.org/Assets/20120726%20nmea%202000%20class%20&%20function%20codes%20v%202.00.pdf
                                2040);    // Just choosen free from code list on https://web.archive.org/web/20190529161431/http://www.nmea.org/Assets/20121020%20nmea%202000%20registration%20list.pdf

  // Here we tell library, which PGNs we transmit
  NMEA2000.ExtendTransmitMessages(TransmitMessages_BATTERY);
}

static void NMEA2000_setup_SHUNT() {
  int chip_id = ChipId();
  String id = get_nmea_name() + " ";
  char name[32];

  Serial.println(F("NMEA2000 setup SHUNT."));

  snprintf(name, sizeof(name), "SHUNT%x07", chip_id);
  NMEA2000.SetProductInformation(name,         // Manufacturer's Model serial code
                                 101,          // Manufacturer's product code
                                 id.c_str(),   // Manufacturer's Model ID
                                 "1.0.0.1 ",   // Manufacturer's Software version code
                                 "1.1.0.0 ");  // Manufacturer's Model version

  // Set device information
  NMEA2000.SetDeviceInformation(chip_id,  // Unique number. Use e.g. Serial number.
                                170,      // Device function=Temperature. See codes on https://web.archive.org/web/20190531120557/https://www.nmea.org/Assets/20120726%20nmea%202000%20class%20&%20function%20codes%20v%202.00.pdf
                                35,       // Device class=Sensor Communication Interface. See codes on https://web.archive.org/web/20190531120557/https://www.nmea.org/Assets/20120726%20nmea%202000%20class%20&%20function%20codes%20v%202.00.pdf
                                2040);    // Just choosen free from code list on https://web.archive.org/web/20190529161431/http://www.nmea.org/Assets/20121020%20nmea%202000%20registration%20list.pdf

  // Here we tell library, which PGNs we transmit
  NMEA2000.ExtendTransmitMessages(TransmitMessages_BATTERY);
}

void NMEA2000_setup() {
  int mode = get_operational_mode();
  int chip_id = ChipId();
  String id = make_nmea_name() + " ";
  char name[32];

  if (!is_valid_operational_mode(mode))
    return;

  // Set Product information
  // NMEA2000.SetDeviceCount(2);  // Enable multi device support for 2 device(s)

  NMEA2000.SetN2kCANSendFrameBufSize(150);
  NMEA2000.SetN2kCANReceiveFrameBufSize(150);

  if (mode == NMEA_MODE_DMC) {
    NMEA2000_setup_DMC();
  }

  if (mode == NMEA_MODE_BMS) {
    NMEA2000_setup_BMS();
  }

  if (mode == NMEA_MODE_SHUNT) {
    NMEA2000_setup_SHUNT();
  }

  // Uncomment 2 rows below to see, what device will send to bus. Use e.g. OpenSkipper or Actisense NMEA Reader
  // NMEA2000.SetForwardStream(&Serial);

  // If you want to use simple ascii monitor like Arduino Serial Monitor, uncomment next line
  // NMEA2000.SetForwardType(tNMEA2000::fwdt_Text); // Show in clear text. Leave uncommented for default Actisense format.

  // If you also want to see all traffic on the bus use N2km_ListenAndNode instead of N2km_NodeOnly below
  NMEA2000.SetMode(tNMEA2000::N2km_ListenAndNode, get_nmea_address());
  // NMEA2000.SetDebugMode(tNMEA2000::dm_Actisense); // Uncomment this, so you can test code without CAN bus chips on Arduino Mega
  // NMEA2000.EnableForward(false);  // Disable all msg forwarding to USB (=Serial)

  // Define OnOpen call back. This will be called, when CAN is open and system starts address claiming.
  NMEA2000.SetOnOpen(OnN2kOpen);
  NMEA2000.Open();
}

/*******************************************************************
  NMEA2000 frame send
 *******************************************************************/
bool NMEA_tx_frames(void) {
  static int memo = 0;
  if (memo != nmea_frame_transmitted) {
    memo = nmea_frame_transmitted;
    return true;
  }
  return false;
}

/*******************************************************************
  NMEA2000 transmit message
 *******************************************************************/
void NMEA2000_Transmit(tN2kMsg N2kMsg, int device = 0) {
  NMEA2000.SendMsg(N2kMsg, device);

  DEBUG_can("NMEA-TX: ", N2kMsg.DataLen, N2kMsg.PGN, 0, N2kMsg.Data);

  nmea_frame_transmitted++;
}

/*******************************************************************
  Send N2k Heartbeat
 *******************************************************************/
void SendN2kHeartbeat() {
  static uint8_t sequenceCounter = 0;
  tN2kMsg N2kMsg;

  if (HeartbeatScheduler.IsTime()) {
    HeartbeatScheduler.UpdateNextTime();

    sequenceCounter = (sequenceCounter + 1) % 252;
    SetHeartbeat(N2kMsg,
                 300,               // Time in 0.01s units
                 sequenceCounter);  // Sequence counter
    NMEA2000_Transmit(N2kMsg);
  }
}

/*******************************************************************
  Check NMEA200 bus address
 *******************************************************************/
void CheckNMEABusAddress() {
  if (AddressCheckScheduler.IsTime()) {
    AddressCheckScheduler.UpdateNextTime();

    if (NMEA2000.ReadResetAddressChanged()) {
      set_nmea_address((int)NMEA2000.GetN2kSource());
    }
  }
}

/*******************************************************************
  Send N2k Engine parameters (rapid)
 *******************************************************************/
void SendN2kEngine_Info() {
  /*  N2kMsg           type N2kMsg       Reference to a N2kMsg Object,
   *  EngineInstance        uint8_t      Engine instance.
   *  EngineSpeed           double       RPM (Revolutions Per Minute)
   *  EngineBoostPressure   double       in Pascal
   *  EngineTiltTrim        uint8_t      in %
   */
  tN2kMsg N2kMsg;
  tN2kEngineDiscreteStatus1 status1;
  tN2kEngineDiscreteStatus2 status2;

  if (EngineRapidScheduler.IsTime()) {
    EngineRapidScheduler.UpdateNextTime();
    SetN2kEngineParamRapid(N2kMsg,
                           get_nmea_instance(),        // unsigned char EngineInstance
                           GetDMCMotorSpeed(),         // double EngineSpeed (rpm)
                           0.0,                        // double EngineBoostPressure=N2kDoubleNA
                           (int8_t)GetDMCThrottle());  // int8_t EngineTiltTrim=N2kInt8NA
    NMEA2000_Transmit(N2kMsg);
  }

  if (EngineDynamicScheduler.IsTime()) {
    EngineDynamicScheduler.UpdateNextTime();

    FaultToNMEAFlag(GetDMCFaultCode(), GetDMCFaultSubCode(), &status1, &status2);

    SetN2kEngineDynamicParam(N2kMsg,
                             get_nmea_instance(),            // unsigned char EngineInstance,
                             0.0,                            // double EngineOilPress,
                             GetDMCMotorTemperature(),       // double EngineOilTemp,
                             GetDMCControllerTemperature(),  // double EngineCoolantTemp,
                             (double)GetDMCMotorVoltage(),   // double AltenatorVoltage,
                             0.0,                            // double FuelRate,
                             0.0,                            // double EngineHours,
                             0.0,                            // double EngineCoolantPress=N2kDoubleNA,
                             0.0,                            // double EngineFuelPress=N2kDoubleNA,
                             0,                              // int8_t EngineLoad=N2kInt8NA,
                             (int8_t)GetDMCActualTorque(),   // int8_t EngineTorque=N2kInt8NA,
                             status1,                        // tN2kEngineDiscreteStatus1 Status1=0,
                             status2);                       // tN2kEngineDiscreteStatus2 Status2=0)
    NMEA2000_Transmit(N2kMsg);
  }
}

/*******************************************************************
  Send N2k Battery parameters (rapid)
 *******************************************************************/
void SendN2kBattery() {
  tN2kMsg N2kMsg;
  double battery_capacity = GetBatteryFullCapacity();

  if (DCBatStatusScheduler.IsTime()) {
    DCBatStatusScheduler.UpdateNextTime();
    SetN2kDCBatStatus(N2kMsg,
                      get_nmea_instance(),          // unsigned char BatteryInstance
                      GetBatteryVoltage(),          // double BatteryVoltage
                      GetBatteryCurrent(),          // double BatteryCurrent=N2kDoubleNA
                      GetBatteryPackTemperature(),  // double BatteryTemperature=N2kDoubleNA
                      1);                           // unsigned char SID=1
    NMEA2000_Transmit(N2kMsg);
  }

  if (DCStatusScheduler.IsTime()) {
    DCStatusScheduler.UpdateNextTime();
    SetN2kDCStatus(N2kMsg,
                   1,                          // unsigned char SID
                   get_nmea_instance(),        // unsigned char DCInstance
                   N2kDCt_Battery,             // tN2kDCType DCType
                   GetBatteryStateOfCharge(),  // unsigned char StateOfCharge
                   92,                         // unsigned char StateOfHealth
                   GetBatteryRemainingTime(),  // double TimeRemaining
                   0.012,                      // double RippleVoltage=N2kDoubleNA
                   battery_capacity);          // double Capacity=N2kDoubleNA
    NMEA2000_Transmit(N2kMsg);
  }

  if (BatConfScheduler.IsTime()) {
    BatConfScheduler.UpdateNextTime();
    SetN2kBatConf(N2kMsg,
                  get_nmea_instance(),            // unsigned char BatInstance
                  N2kDCbt_Gel,                    // tN2kBatType BatType
                  N2kDCES_Yes,                    // tN2kBatEqSupport SupportsEqual
                  N2kDCbnv_48v,                   // tN2kBatNomVolt BatNominalVoltage
                  N2kDCbc_LiIon,                  // tN2kBatChem BatChemistry
                  AhToCoulomb(battery_capacity),  // double BatCapacity (0 ... 1000)
                  53,                             // int8_t BatTemperatureCoefficient (%)
                  1.01,                           // double PeukertExponent
                  90);                            // int8_t ChargeEfficiencyFactor (%)
    NMEA2000_Transmit(N2kMsg);
  }
}

/*******************************************************************
  Loop
 *******************************************************************/
static void NMEA_main_task(void* parameter) {
  (void)parameter;
  int mode = get_operational_mode();

  while (true) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
    NMEA2000.ParseMessages();

    switch (mode) {
      case NMEA_MODE_BMS:
        if (!BMS_error()) {
          SendN2kHeartbeat();
          SendN2kBattery();
        }
        break;
      case NMEA_MODE_DMC:
        if (!DMC_error()) {
          SendN2kHeartbeat();
          SendN2kEngine_Info();
        }
        break;
      case NMEA_MODE_SHUNT:
        if (!VED_error()) {
          SendN2kHeartbeat();
          SendN2kBattery();
        }
        break;
      default:
        // Nothing to do...
        break;
    } // end switch()
  
    CheckNMEABusAddress();
  }
}

/*******************************************************************
 *  Setup tasks
 *******************************************************************/
static void NMEA_setup_tasks() {
  xTaskCreate(NMEA_main_task, "NMEA main task", 4096, NULL, 10, NULL);
}

/*********************************************************************
 * REST API: read handler
 *********************************************************************/
void NMEA_rest_read(AsyncWebServerRequest* request) {
  String str;
  serializeJson(NMEA_json(), str);
  request->send(200, "application/json", str.c_str());
}

static rest_api_t NMEA_api_handlers = {
    /* uri */ "/api/v1/nmea",
    /* comment */ "NMEA module",
    /* instances */ 1,
    /* fn_create */ nullptr,
    /* fn_read */ NMEA_rest_read,
    /* fn_update */ nullptr,
    /* fn_delete */ nullptr,
};

/*********************************************************************
 * NMEA commandline handlers
 ********************************************************************/
static void clicb_NMEA_handler(cmd* c) {
  Command cmd(c);
  Argument arg = cmd.getArg(0);
  String strArg = arg.getValue();

  /* List settings */
  if (strArg.isEmpty()) {
    CLI_println(NMEA_string());
    return;
  }

  /* Set NMEA Instance */
  if (strArg.equalsIgnoreCase("instance")) {
    arg = cmd.getArg(1);
    strArg = arg.getValue();

    nmea_instance = min(99, max(1, (int)strArg.toInt()));
    STORAGE_set_int(JSON_NMEA_INSTANCE, nmea_instance);
    set_nmea_name(make_nmea_name());
    CLI_println(String("NMEA set instance to " + String(nmea_instance) + "."));
    return;
  }

  /* Set NMEA address */
  if (strArg.equalsIgnoreCase("address")) {
    arg = cmd.getArg(1);
    strArg = arg.getValue();

    nmea_address = min(99, max(1, (int)strArg.toInt()));
    STORAGE_set_int(JSON_NMEA_ADDRESS, nmea_address);
    CLI_println(String("NMEA set bus address to " + String(nmea_address) + "."));
    return;
  }

  CLI_println("Invalid command: NMEA (instance <n>, address <n>).");
}

/*********************************************************************
 * NMEA mode commandline handlers
 ********************************************************************/
static void clicb_MODE_handler(cmd* c) {
  Command cmd(c);

  Argument arg = cmd.getArg(0);
  String strArg = arg.getValue();

  if (strArg.isEmpty()) {
    int mode = get_operational_mode();
    CLI_println(String("Current operational mode is " + OperationalModeStr(mode)));
    return;
  }

  if (strArg.equalsIgnoreCase("none")) {
    set_operational_mode(NMEA_MODE_UNKNOWN);
    CLI_println("Operational mode set to UNKNONW.");
    system_restart();
    return;
  }

  if (strArg.equalsIgnoreCase("bms")) {
    set_operational_mode(NMEA_MODE_BMS);
    CLI_println("Operational mode set to BMS.");
    system_restart();
    return;
  }

  if (strArg.equalsIgnoreCase("dmc")) {
    set_operational_mode(NMEA_MODE_DMC);
    CLI_println("Operational mode set to DMC.");
    system_restart();
    return;
  }

  if (strArg.equalsIgnoreCase("shunt")) {
    set_operational_mode(NMEA_MODE_SHUNT);
    CLI_println("Operational mode set to SHUNT.");
    system_restart();
    return;
  }

  CLI_println("Invalid command: mode (none, bms, dmc, shunt).");
  return;
}

/********************************************************************
 * NMEA Setup variables
 ********************************************************************/
void NMEA_setup_variables(void) {
  /* Converter mode (BMS, DMC or SHUNT) */
  if (STORAGE_get_int(JSON_NMEA_MODE, nmea_operational_mode)) {
    nmea_operational_mode = NMEA_MODE_UNKNOWN;
    STORAGE_set_int(JSON_NMEA_MODE, nmea_operational_mode);
  }

  /* NMEA2000 instance number (for BMS, DMC and SHUNT) */
  if (STORAGE_get_int(JSON_NMEA_INSTANCE, nmea_instance)) {
    nmea_instance = 1;
    STORAGE_set_int(JSON_NMEA_INSTANCE, nmea_instance);
  }

  /* NMEA2000 bus address */
  if (STORAGE_get_int(JSON_NMEA_ADDRESS, nmea_address)) {
    nmea_address = 23;
    STORAGE_set_int(JSON_NMEA_ADDRESS, nmea_address);
  }

  /* NMEA2000 bus address */
  if (STORAGE_get_string(JSON_NMEA_NAME, nmea_name)) {
    nmea_name = make_nmea_name();
    STORAGE_set_string(JSON_NMEA_NAME, nmea_name);
  }
}

/*********************************************************************
 *  Setup commandline handlers
 ********************************************************************/
static void NMEA_cli_handlers(void) {
  cli.addBoundlessCmd("nmea", clicb_NMEA_handler);
  cli.addBoundlessCmd("mode", clicb_MODE_handler);
}

/*******************************************************************
 * Setup NMEA
 *******************************************************************/
void NMEA_setup(void) {
  NMEA_setup_variables();
}

/*******************************************************************
 * Start NMEA
 *******************************************************************/
void NMEA_start(void) {
  NMEA2000_setup();
  NMEA_setup_tasks();

  NMEA_cli_handlers();
  setup_uri(&NMEA_api_handlers);

  Serial.println("NMEA2000 setup completed...");
}
