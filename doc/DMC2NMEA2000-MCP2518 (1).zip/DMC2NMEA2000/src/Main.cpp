
// EBC-E ESP32 base system
#include <Arduino.h>

#include "CLI.h"
#include "Config.h"
#include "Debug.h"
#include "MCPCom.h"
#include "Storage.h"
#include "WebServer.h"
#include "WiFiCom.h"
#include "NMEA.h"

#include "BMS.h"
#include "DMC.h"
#include "VED.h"
#include "NMEA.h"

/********************************************************************
 * Defintitions
 ********************************************************************/

/********************************************************************
 * Global data
 ********************************************************************/

/*******************************************************************
    Setup leds
 *******************************************************************/
void LED_setup(void) {
  // Initialize pinning
  pinMode(HeartBeat_LedPin, OUTPUT);  // Software running heartbeat LED
  pinMode(Error_LedPin, OUTPUT);      // General system error LED
  pinMode(TWAI_LedPin, OUTPUT);       // Monitor MCP bus activity
  pinMode(MCP_LedPin, OUTPUT);        // Monitor NMEA bus activity
  pinMode(VED_LedPin, OUTPUT);        // Monitor VEDirect channel activity

  // All leds on
  digitalWrite(HeartBeat_LedPin, HIGH);
  digitalWrite(Error_LedPin, HIGH);
  digitalWrite(TWAI_LedPin, HIGH);
  digitalWrite(MCP_LedPin, HIGH);
  digitalWrite(VED_LedPin, HIGH);

  delay(1000);

  // All leds off
  digitalWrite(HeartBeat_LedPin, LOW);
  digitalWrite(Error_LedPin, LOW);
  digitalWrite(TWAI_LedPin, LOW);
  digitalWrite(MCP_LedPin, LOW);
  digitalWrite(VED_LedPin, LOW);

  delay(1000);

  // Turn alarm led constant on
  digitalWrite(Error_LedPin, HIGH);  // Will be cleared by peridic update
}

/*******************************************************************
 * LED control
 *
 *******************************************************************/
void MCP_led_task(void* parameter) {
  (void)parameter;

  while (true) {
    digitalWrite(MCP_LedPin, LOW);
    vTaskDelay(50 / portTICK_PERIOD_MS);
    if (MCP1_rx_frames())
      digitalWrite(MCP_LedPin, HIGH);
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void TWAI_led_task(void* parameter) {
  (void)parameter;

  while (true) {
    digitalWrite(TWAI_LedPin, LOW);
    vTaskDelay(50 / portTICK_PERIOD_MS);
    if (NMEA_tx_frames())
      digitalWrite(TWAI_LedPin  , HIGH);
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void VED_led_task(void* parameter) {
  (void)parameter;

  while (true) {
    digitalWrite(VED_LedPin, LOW);
    vTaskDelay(50 / portTICK_PERIOD_MS);
    if (VED_Frame_Received())
      digitalWrite(VED_LedPin, HIGH);
    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

/*******************************************************************
  Loop
 ********************************************************************/
void loop() {
  static int led_status = 0;

  /* Syncronized blinking of error and hartbeat leds. */
  vTaskDelay(500 / portTICK_PERIOD_MS);

  led_status = !digitalRead(HeartBeat_LedPin);
  digitalWrite(HeartBeat_LedPin, led_status);

  switch (get_operational_mode()) {
    case NMEA_MODE_DMC:
      digitalWrite(Error_LedPin, DMC_error() ? led_status : LOW);
      break;

    case NMEA_MODE_BMS:
      digitalWrite(Error_LedPin, BMS_error() ? led_status : LOW);
      break;

    case NMEA_MODE_SHUNT:
      digitalWrite(Error_LedPin, VED_error() ? led_status : LOW);
      break;

    default:
      digitalWrite(Error_LedPin, led_status);
      break;
  }
}

/********************************************************************
 * CLI: Show all cli commands and descriptions
 ********************************************************************/
static void clicb_help(cmd *c) {
  (void)c;

  CLI_println(F("--- Help commands ---"));
  CLI_println(F("[?] ~ Help information."));
  CLI_println(F("[!] ~ System information."));
  CLI_println(F("[web] ~ Web-server information."));
  CLI_println(F("[wifi] ~ WiFi information."));
  CLI_println(F("[mcp] ~ MCP information."));
  CLI_println(F("[storage] ~ List settings."));
  CLI_println(F("[restart] ~ Restart the system."));
  CLI_println(F("[data] ~ Internal data trace on/off."));
  CLI_println(F("[frames] ~ Extrenal comminucation trace on/off."));
  CLI_println(F("[bus] ~ Low level CAN bus trace on/off."));
  CLI_println(F("[factory...] ~ Factory reset settings (yes)"));
  CLI_println(F("[mode...] ~ Set operational mode (none, bms, dmc, shunt)."));
  CLI_println(F("[nmea...] ~ Set NMEA2000 parameters (instance <n>, address <n>)."));
  CLI_println(F("[bms...] ~ List/set BMS parameters (floor <n>)."));
  CLI_println(F("[dmc] ~ List DMC parameters."));
  CLI_println(F("[shunt] ~ List SHUNT parameters."));
}

/********************************************************************
 * CLI: Show all cli commands and descriptions
 ********************************************************************/
static void clicb_system(cmd *c) {
  (void)c;
  String text;
  int mode = get_operational_mode();

  text = "--- System ---";

  text.concat("\r\nProgram title: ");
  text.concat(ProgramTitle);

  text.concat("\r\nProgram name: ");
  text.concat(ProgramName);
  text.concat(", version: ");
  text.concat(ProgramVersion);

  text.concat("\r\nNMEA mode: ");
  text.concat(OperationalModeStr(mode).c_str());
  text.concat(", instance: ");
  text.concat(get_nmea_instance());
  text.concat(", address: ");
  text.concat(get_nmea_address());

  text.concat("\r\nWiFi ssid: ");
  text.concat(WiFi_ssid());
  text.concat(", MAC: ");
  text.concat(WiFi_mac());

  text.concat("\r\nHardware id: ");
  text.concat(ChipIds());
  text.concat(", PCB version: ");
  text.concat(PCBVersion);

  text.concat("\r\nFlash size(MB): ");
  text.concat(ESP.getFlashChipSize() / (1024 * 1024));
  text.concat(", Free memory(kB): ");
  text.concat((ESP.getFreeHeap() / 1024));

  text.concat("\r\n");
  CLI_println(text);
}

/********************************************************************
 *  Initialize the command line handlers
 *
 ********************************************************************/
static void MAIN_handlers(void) {
  cli.addCommand("?,help", clicb_help);
  cli.addCommand("!,system", clicb_system);
}

/*******************************************************************
 *  Setup tasks
 *******************************************************************/
void MAIN_setup_tasks() {
  xTaskCreate(MCP_led_task, "MCP receive led task", 2048, NULL, 10, NULL);
  xTaskCreate(TWAI_led_task, "NMEA transmit led task", 1024, NULL, 10, NULL);
  xTaskCreate(VED_led_task, "SHUNT receive led task", 2048, NULL, 10, NULL);
}

/*******************************************************************
    Setup
 ********************************************************************/
void setup() {
  Serial.begin(115200);
  delay(1000); /* Wait before logging startup */

  /* System setup, don not change order... */
  LED_setup();        // 1. Init LED's
  STORAGE_setup();    // 2. Initialise storage
  WiFi_setup();       // 3. Startup WiFi
  CLI_setup();        // 4. Initialise CommandLine Interface
  WEBSERVER_setup();  // 5. Start WebServer and WebSockerServer
  DEBUG_setup();      // 6. Initialise debugging

  NMEA_setup();       // Read operational mode...
  DMC_setup();        //
  BMS_setup();        //
  VED_setup();        //

  int mode = get_operational_mode();
  String mode_str = OperationalModeStr(mode);
  Serial.printf("MAIN operational mode is: %s.\r\n", mode_str.c_str());
  BMS_start(mode == NMEA_MODE_BMS);
  DMC_start(mode == NMEA_MODE_DMC);
  VED_start(mode == NMEA_MODE_SHUNT);

  NMEA_start();
  MAIN_handlers();
  MAIN_setup_tasks();

  Serial.println(F("Main setup completed..."));
}
