/*********************************************************************
 *    BMS_RIM.ino
 *
 *    Data handling for Battery Management System (BMS)
 *
 ********************************************************************/
#include <Arduino.h>
#include <ArduinoJson.h>
#include <Endian.h>
#include <Math.h>
#include "WebServer.h"

#include "CLI.h"
#include "Config.h"
#include "Debug.h"
#include "MCPCom.h"
#include "StateMachineLib.h"
#include "Storage.h"

#include "BMS.h"

/*********************************************************************
 * Constants
 ********************************************************************/
#undef DEBUG_FRAMES       // Debugging to Serial
#undef DEBUG_REQUESTS     // Debugging to Serial
#undef DEBUG_STATEMACHINE // Debugging to Serial

#define DEFAULT_INSTANCE 0

#define REQUEST_IDLE_MS 3000
#define REQUEST_TIMEOUT_MS 1000

#define MAX_AMPERES_AVERAGE 10

#define INITAL_FLOOR_FACTOR 0.0  // %

/*********************************************************************
 * Type definitions
 ********************************************************************/
enum StateIds {
  idStateS1 = 0,
  idStateS2,
  idStateS3,
  idStateS4
};

typedef struct bms_data_t {
  // BMS ID  0x100  Volt Aampere
  int16_t Bat_Voltage;        // waarde x 0.01 Volt
  int16_t Bat_Ampere;         // waarde x 0.01 Amp
  int16_t Bat_Remaining_Cap;  // waarde x 0.01 Ah

  // BMS ID  0x101  Capacity
  int16_t Bat_Full_Cap;  // waarde x 0.01 Ah
  int16_t Bat_Cycles;    // Aantal Cycles
  int16_t Bat_SOC;       // waarde %

  // BMS ID  0x102  Cell Status (8 bytes)
  uint16_t Balance_C_1_16;   // Ballance state of Cell 01 to 16 (bit 0 = cell 01 ,bit 15 = Cell 16
  uint16_t Balance_C_17_33;  // Ballance state of Cell 17 to 32 (bit 0 = cell 17 ,bit 15 = Cell 32
  uint16_t Status_1_2;       // bit 0 = Single cell over voltage
                             // bit 1 = Single cell under voltage
                             // bit 2 = Pack over voltage
                             // bit 3 = Pack under voltage
                             // bit 4 = Charge over temp
                             // bit 5 = Charge under temp
                             // bit 6 = Discharge over temp
                             // bit 7 = Discharge under temp
                             // bit 8 = Charge over current
                             // bit 9 = Discharge over current
                             // bit 10 = Short circuit
                             // bit 11 = BMS IC Error
                             // bit 12 = Software FET lock
                             // bit 13 = none
                             // bit 14 = none
                             // bit 15 = none

  // BMS ID  0x103  Pack info (8 bytes) inclusief CRC
  uint8_t Char_Fet;       // Charge Fet State (0xFF = On , 0x00 = Off)
  uint8_t DChar_Fet;      // Discharge Fet State (0xFF = On , 0x00 = Off)
  uint16_t Prod_Date;     // Production date of the BMS (16 bits)
                          // bit 0  = day bit 0     (Prod_Date & 0x1F)
                          // bit 1  = day bit 1
                          // bit 2  = day bit 2
                          // bit 3  = day bit 3
                          // bit 4  = day bit 4
                          // bit 5  = month bit 0
                          // bit 6  = month bit 1
                          // bit 7  = month bit 2
                          // bit 8  = month bit 3
                          // bit 9  = Year bit 0  counting from 2000
                          // bit 10 = Year bit 1  counting from 2000
                          // bit 11 = Year bit 2  counting from 2000
                          // bit 12 = Year bit 3  counting from 2000
                          // bit 13 = Year bit 4  counting from 2000
                          // bit 14 = Year bit 5  counting from 2000
                          // bit 15 = Year bit 6  counting from 2000
  uint16_t Firm_version;  // BMS firmware version

  // BMS ID  0x104  number information of batterie and NTC´s (4 bytes)inclusief CRC
  uint8_t Bat_Nr;  // Number of batteries
  uint8_t NTC_Nr;  // Number of NTC´s

  // BMS ID  0x105  NTC information (8 bytes)inclusief CRC
  uint16_t Temp_NTC01;  // Temperature NTC 01 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10
  uint16_t Temp_NTC02;  // Temperature NTC 02
  uint16_t Temp_NTC03;  // Temperature NTC 03

  // BMS ID  0x106  NTC information (8 bytes)inclusief CRC
  uint16_t Temp_NTC04;  // Temperature NTC 04 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10
  uint16_t Temp_NTC05;  // Temperature NTC 05
  uint16_t Temp_NTC06;  // Temperature NTC 06

  // BMS ID  0x107  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_01;  // Voltage van Cell in mV
  uint16_t V_rim_02;  // Voltage van Cell in mV
  uint16_t V_rim_03;  // Voltage van Cell in mV

  // BMS ID  0x108  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_04;  // Voltage van Cell in mV
  uint16_t V_rim_05;  // Voltage van Cell in mV
  uint16_t V_rim_06;  // Voltage van Cell in mV

  // BMS ID  0x109  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_07;  // Voltage van Cell in mV
  uint16_t V_rim_08;  // Voltage van Cell in mV
  uint16_t V_rim_09;  // Voltage van Cell in mV

  // BMS ID  0x10A  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_10;  // Voltage van Cell in mV
  uint16_t V_rim_11;  // Voltage van Cell in mV
  uint16_t V_rim_12;  // Voltage van Cell in mV

  // BMS ID  0x10B  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_13;  // Voltage van Cell in mV
  uint16_t V_rim_14;  // Voltage van Cell in mV
  uint16_t V_rim_15;  // Voltage van Cell in mV

  // BMS ID  0x10C  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_16;  // Voltage van Cell in mV
  uint16_t V_rim_17;  // Voltage van Cell in mV
  uint16_t V_rim_18;  // Voltage van Cell in mV

  // BMS ID  0x10D  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_19;  // Voltage van Cell in mV
  uint16_t V_rim_20;  // Voltage van Cell in mV
  uint16_t V_rim_21;  // Voltage van Cell in mV

  // BMS ID  0x10E  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_22;  // Voltage van Cell in mV
  uint16_t V_rim_23;  // Voltage van Cell in mV
  uint16_t V_rim_24;  // Voltage van Cell in mV

  // BMS ID  0x10F  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_25;  // Voltage van Cell in mV
  uint16_t V_rim_26;  // Voltage van Cell in mV
  uint16_t V_rim_27;  // Voltage van Cell in mV

  // BMS ID  0x110  NTC information (8 bytes)inclusief CRC
  uint16_t V_rim_28;  // Voltage van Cell in mV
  uint16_t V_rim_29;  // Voltage van Cell in mV
  uint16_t V_rim_30;  // Voltage van Cell in mV

  // BMS ID 0x355
  uint16_t SOC;  // State of Charge waarde = uint8_t 0 = LSB , uint8_t 1 = MSB

  // BMS ID 0x356
  uint16_t Pack_Voltage;  // in mVolt waarde = uint8_t 0 = LSB , uint8_t 1 = MSB
  uint16_t Pack_Ampere;   // in mAmp  waarde = uint8_t 2 = LSB , uint8_t 3 = MSB
  uint16_t Pack_Temp;     // in  0,1 Gr. celsius waarde = uint8_t 4 = LSB , uint8_t 5 = MSB
} bms_data_t;

/*********************************************************************
 * Global data
 ********************************************************************/
static bms_data_t bms_data[1];

static uint32_t bms_frames_received = 0;
static int bms_error_delay = 0;

static float bms_floor_factor = INITAL_FLOOR_FACTOR;

StateMachine stateMachine(4, 4);

static unsigned long bms_request_starttime;
static bool bms_id_100_received, bms_id_101_received, bms_id_105_received;

static double Battery_Ampere_Average = 0.0;
static double ampere_average[MAX_AMPERES_AVERAGE] = {0.0};

/********************************************************************
 * BMS frames received
 *******************************************************************/
bool BMS_data_received(void) {
  static int memo = 0;
  if (memo < bms_frames_received) {
    memo = bms_frames_received;
    return true;
  }
  return false;
}

/********************************************************************
 * BMS error status
 *******************************************************************/
bool BMS_error(void) {
  return (bms_error_delay == 0);
}

/********************************************************************
 * BMS frame received
 *******************************************************************/
static void BMS_frame_received(void) {
  /* Increment received frame counter */
  bms_frames_received++;

  /* Reload error countdown */
  bms_error_delay = ERROR_DELAY_PRELOAD;
}

/*********************************************************************
 * Get the battery floor-factor
 ********************************************************************/
static float get_floor_factor(void) {
  return bms_floor_factor;
}

/*********************************************************************
 * Set the battery floor-factor
 ********************************************************************/
static void set_floor_factor(float value) {
  if ((value >= 0.0) && (value <= 100.0)) {
    bms_floor_factor = value;
  }
}

/*********************************************************************
 * Calculate average
 *
 ********************************************************************/
static double CalcAverage(double list[], int max, double value) {
  static int ndx = 0;
  double average = 0;

  if (max < 2)
    return 0.0;

  ndx = (ndx + 1) % max;
  list[ndx] = value;

  for (int i = 0; i < max; i++)
    average += list[i];

  return (average / max);
}

/*********************************************************************
 *    Decode Production Date send by Battery BMS
 *
 *    Word =>  Day    = Bit 0,1,2,3,4
 *             Month  = Bit 5,6,7,8
 *             Year   = Bit 9,10,11,12,13,14,15 + 2000
 *
 *    Return string = yyyy-mm-dd
 *
 ********************************************************************/
String DecodeDate(word Date) {
  char buf[16];
  int Day, Month, Year, Test;

  String DateValue = "dd-mm-yyyy";

  // Day decodation
  Day = Date & 0x001F;

  // Month decodation
  Test = Date >> 5;
  Month = Test & 0x000F;

  // Year decodation
  Test = Date & 0xFE00;
  Year = Test >> 9;
  Year += 2000;

  snprintf(buf, sizeof(buf), " %2d-%2d-%4d", Day, Month, Year);
  return String(buf);
}

/*********************************************************************
 *  Get battery voltage (double, 2 decimals, V)
 ********************************************************************/
double GetBMSBatteryVoltage(void) {
  return (double)(bms_data[DEFAULT_INSTANCE].Bat_Voltage / 100.0);
};

/*********************************************************************
 *  Get battery amperes (double, 2 decimal, A)
 ********************************************************************/
double GetBMSBatteryCurrent(void) {
  return (double)(bms_data[DEFAULT_INSTANCE].Bat_Ampere / 100.0);
};

/*********************************************************************
 *  Get battery amperes average (double, 0 decimal, A)
 ********************************************************************/
double GetBMSBatteryAmperesAverage(void) {
  return (double)Battery_Ampere_Average;
};

/*********************************************************************
 *  Get battery remaining capacity (double, 2 decimal, Ah)
 ********************************************************************/
double GetBMSBatteryRemainingCapacity(void) {
  double floor_factor = (100.0 - get_floor_factor()) / 100.0;
  return ((double)bms_data[DEFAULT_INSTANCE].Bat_Remaining_Cap * floor_factor) / 100.0;
};

/*********************************************************************
 *  Get battery remaining time (double, sec.)
 ********************************************************************/
double GetBMSBatteryRemainingTime(void) {
  double amps = GetBMSBatteryAmperesAverage();
  if (amps != 0.0) {
    double remaining = GetBMSBatteryRemainingCapacity();  // Alread includes floor factor
    return ((abs(remaining) * 3600.0) / abs(amps));
  }
  return 0.0;
};

/*********************************************************************
 *  Get battery full capacity (double, 1 decimal, Ah)
 ********************************************************************/
double GetBMSBatteryFullCapacity(void) {
  return (double)(bms_data[DEFAULT_INSTANCE].Bat_Full_Cap / 100.0);
};

/*********************************************************************
 *  Get battery cycles (integer, cycles)
 ********************************************************************/
int16_t GetBMSBatteryCycles(void) {
  return bms_data[DEFAULT_INSTANCE].Bat_Cycles;
};

/*********************************************************************
 *  Get battery State Of Charge (integer, %)
 ********************************************************************/
int8_t GetBMSBatteryStateOfCharge(void) {
  return (uint8_t)bms_data[DEFAULT_INSTANCE].Bat_SOC;
};

/*********************************************************************
 *  Get battery pack temperature (0.1, dgr.C)
 ********************************************************************/
double GetBMSBatteryPackTemperature(void) {
  return (bms_data[DEFAULT_INSTANCE].Pack_Temp / 10.0) + 273.16;
};

/*********************************************************************
 *  BMS process frame with id=0x100
 *
 ********************************************************************/
static String BMS_frame_100_to_string() {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: %3.1fV, current: %4.1fA, remaining cap.: %4.1fAh.",
           GetBMSBatteryVoltage(),
           GetBMSBatteryCurrent(),
           GetBMSBatteryRemainingCapacity());
  return msg;
}

void BMS_process_frame_100(uint8_t *buffer, int size) {
  struct data_fmt {
    int16_t Bat_Voltage;        // waarde x 0.01 Volt
    int16_t Bat_Ampere;         // waarde x 0.01 Amp
    int16_t Bat_Remaining_Cap;  // waarde x 0.01 Ah
    uint16_t CRC;               // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Bat_Voltage = bswap16(ptr->Bat_Voltage);
  bms_data[DEFAULT_INSTANCE].Bat_Ampere = bswap16(ptr->Bat_Ampere);
  bms_data[DEFAULT_INSTANCE].Bat_Remaining_Cap = bswap16(ptr->Bat_Remaining_Cap);

  Battery_Ampere_Average = CalcAverage(&ampere_average[0], MAX_AMPERES_AVERAGE, GetBMSBatteryCurrent());

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x100 received.");
#endif

  String txt = "0x100-Battery: " + BMS_frame_100_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x101
 *
 ********************************************************************/
static String BMS_frame_101_to_string() {
  char msg[64];
  snprintf(msg, sizeof(msg), "Full cap.: %4.1fAh, remaining time: %1.0fs, cycles: %d, SOC: %d%%.",
           GetBMSBatteryFullCapacity(),
           GetBMSBatteryRemainingTime(),
           (int)GetBMSBatteryCycles(),
           (int)GetBMSBatteryStateOfCharge());
  return msg;
}

void BMS_process_frame_101(uint8_t *buffer, int size) {
  struct data_fmt {
    int16_t Bat_Full_Cap;  // waarde x 0.01 Ah
    int16_t Bat_Cycles;    // Aantal Cycles
    int16_t Bat_SOC;       // waarde %
    uint16_t CRC0x101;     // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Bat_Full_Cap = bswap16(ptr->Bat_Full_Cap);
  bms_data[DEFAULT_INSTANCE].Bat_Cycles = bswap16(ptr->Bat_Cycles);
  bms_data[DEFAULT_INSTANCE].Bat_SOC = bswap16(ptr->Bat_SOC);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x101 received.");
#endif

  String txt = "0x101-Battery: " + BMS_frame_101_to_string();
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x102
 *
 ********************************************************************/
static String BMS_frame_102_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Balance C1-16: %d, Balance C17-33: %d, Status1-2: %d.",
           data->Balance_C_1_16, data->Balance_C_17_33, data->Status_1_2);
  return msg;
}

void BMS_process_frame_102(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t Balance_C_1_16;   // Ballance state of Cell 01 to 16 (bit 0 = cell 01 ,bit 15 = Cell 16
    uint16_t Balance_C_17_33;  // Ballance state of Cell 17 to 32 (bit 0 = cell 17 ,bit 15 = Cell 32
    uint16_t Status_1_2;       // bit 0 = Single cell over voltage
                               // bit 1 = Single cell under voltage
                               // bit 2 = Pack over voltage
                               // bit 3 = Pack under voltage
                               // bit 4 = Charge over temp
                               // bit 5 = Charge under temp
                               // bit 6 = Discharge over temp
                               // bit 7 = Discharge under temp
                               // bit 8 = Charge over current
                               // bit 9 = Discharge over current
                               // bit 10 = Short circuit
                               // bit 11 = BMS IC Error
                               // bit 12 = Software FET lock
                               // bit 13 = none
                               // bit 14 = none
                               // bit 15 = none
    uint16_t CRC;              // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Balance_C_1_16 = bswap16(ptr->Balance_C_1_16);
  bms_data[DEFAULT_INSTANCE].Balance_C_17_33 = bswap16(ptr->Balance_C_17_33);
  bms_data[DEFAULT_INSTANCE].Status_1_2 = bswap16(ptr->Status_1_2);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x102 received.");
#endif

  String txt = "0x102-Battery: " + BMS_frame_102_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x103
 *
 ********************************************************************/
static String BMS_frame_103_to_string(struct bms_data_t *data) {
  char msg[128];
  String date = DecodeDate((word)data->Prod_Date);

  snprintf(msg, sizeof(msg), "Charge FET state: %d, Decharge FET state: %d, Production date: %s, Firmware version: %d.",
           (int)data->Char_Fet, (int)data->DChar_Fet, date.c_str(), data->Firm_version);
  return msg;
}

void BMS_process_frame_103(uint8_t *buffer, int size) {
  struct data_fmt {
    uint8_t Char_Fet;       // Charge Fet State (0xFF = On , 0x00 = Off)
    uint8_t DChar_Fet;      // Discharge Fet State (0xFF = On , 0x00 = Off)
    uint16_t Prod_Date;     // Production date of the BMS (16 bits)
                            // bit 0  = day bit 0     (Prod_Date & 0x1F)
                            // bit 1  = day bit 1
                            // bit 2  = day bit 2
                            // bit 3  = day bit 3
                            // bit 4  = day bit 4
                            // bit 5  = month bit 0
                            // bit 6  = month bit 1
                            // bit 7  = month bit 2
                            // bit 8  = month bit 3
                            // bit 9  = Year bit 0  counting from 2000
                            // bit 10 = Year bit 1  counting from 2000
                            // bit 11 = Year bit 2  counting from 2000
                            // bit 12 = Year bit 3  counting from 2000
                            // bit 13 = Year bit 4  counting from 2000
                            // bit 14 = Year bit 5  counting from 2000
                            // bit 15 = Year bit 6  counting from 2000
    uint16_t Firm_version;  // BMS firmware version
    uint16_t CRC;           // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Char_Fet = bswap16(ptr->Char_Fet);
  bms_data[DEFAULT_INSTANCE].DChar_Fet = bswap16(ptr->DChar_Fet);
  bms_data[DEFAULT_INSTANCE].Prod_Date = bswap16(ptr->Prod_Date);
  bms_data[DEFAULT_INSTANCE].Firm_version = bswap16(ptr->Firm_version);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x103 received.");
#endif

  String txt = "0x103-Battery: " + BMS_frame_103_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x104
 *
 ********************************************************************/
static String BMS_frame_104_to_string(struct bms_data_t *data) {
  char msg[128];
  snprintf(msg, sizeof(msg), "Number of bateries: %d, number of NTCs: %d.",
           (int)data->Bat_Nr, (int)data->NTC_Nr);
  return msg;
}

void BMS_process_frame_104(uint8_t *buffer, int size) {
  struct data_fmt {
    uint8_t Bat_Nr;  // Number of batteries
    uint8_t NTC_Nr;  // Number of NTC´s
    uint16_t CRC;    // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Bat_Nr = ptr->Bat_Nr;
  bms_data[DEFAULT_INSTANCE].NTC_Nr = ptr->NTC_Nr;

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x104 received.");
#endif

  String txt = "0x104-Battery: " + BMS_frame_104_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x105
 *
 ********************************************************************/
static String BMS_frame_105_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "NTC-1: %d, NTC-2: %d, NTC-3: %d.",
           data->Temp_NTC01, data->Temp_NTC02, data->Temp_NTC03);
  return msg;
}

void BMS_process_frame_105(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t Temp_NTC01;  // Temperature NTC 01 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10
    uint16_t Temp_NTC02;  // Temperature NTC 02
    uint16_t Temp_NTC03;  // Temperature NTC 03
    uint16_t CRC;         // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Temp_NTC01 = bswap16(ptr->Temp_NTC01);
  bms_data[DEFAULT_INSTANCE].Temp_NTC02 = bswap16(ptr->Temp_NTC02);
  bms_data[DEFAULT_INSTANCE].Temp_NTC03 = bswap16(ptr->Temp_NTC03);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x105 received.");
#endif

  String txt = "0x105-Battery: " + BMS_frame_105_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x106
 *
 ********************************************************************/
static String BMS_frame_106_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "NTC-4: %d, NTC-5: %d, NTC-6: %d.",
           data->Temp_NTC04, data->Temp_NTC05, data->Temp_NTC06);
  return msg;
}

void BMS_process_frame_106(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t Temp_NTC04;  // Temperature NTC 04 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10
    uint16_t Temp_NTC05;  // Temperature NTC 05
    uint16_t Temp_NTC06;  // Temperature NTC 06
    uint16_t CRC;         // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Temp_NTC04 = bswap16(ptr->Temp_NTC04);
  bms_data[DEFAULT_INSTANCE].Temp_NTC05 = bswap16(ptr->Temp_NTC05);
  bms_data[DEFAULT_INSTANCE].Temp_NTC06 = bswap16(ptr->Temp_NTC06);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x106 received.");
#endif

  String txt = "0x106-Battery: " + BMS_frame_106_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x107
 *
 ********************************************************************/
static String BMS_frame_107_to_string(struct bms_data_t *data) {
  char msg[128];
  snprintf(msg, sizeof(msg), "Voltage: cell 1: %d, cell 2: %d, cell 3: %d.",
           data->V_rim_01, data->V_rim_02, data->V_rim_03);
  return msg;
}

void BMS_process_frame_107(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_01;  // Voltage van Cell in mV
    uint16_t V_rim_02;  // Voltage van Cell in mV
    uint16_t V_rim_03;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_01 = bswap16(ptr->V_rim_01);
  bms_data[DEFAULT_INSTANCE].V_rim_02 = bswap16(ptr->V_rim_02);
  bms_data[DEFAULT_INSTANCE].V_rim_03 = bswap16(ptr->V_rim_03);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x107 received.");
#endif

  String txt = "0x107-Battery: " + BMS_frame_107_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x108
 *
 ********************************************************************/
static String BMS_frame_108_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 4: %d, cell 5: %d, cell 6: %d.",
           data->V_rim_04, data->V_rim_05, data->V_rim_06);
  return msg;
}

void BMS_process_frame_108(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_04;  // Voltage van Cell in mV
    uint16_t V_rim_05;  // Voltage van Cell in mV
    uint16_t V_rim_06;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_04 = bswap16(ptr->V_rim_04);
  bms_data[DEFAULT_INSTANCE].V_rim_05 = bswap16(ptr->V_rim_05);
  bms_data[DEFAULT_INSTANCE].V_rim_06 = bswap16(ptr->V_rim_06);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x108 received.");
#endif

  String txt = "0x108-Battery: " + BMS_frame_108_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x109
 *
 ********************************************************************/
static String BMS_frame_109_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 7: %d, cell 8: %d, cell 9: %d.",
           data->V_rim_07, data->V_rim_08, data->V_rim_09);
  return msg;
}

void BMS_process_frame_109(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_07;  // Voltage van Cell in mV
    uint16_t V_rim_08;  // Voltage van Cell in mV
    uint16_t V_rim_09;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_07 = bswap16(ptr->V_rim_07);
  bms_data[DEFAULT_INSTANCE].V_rim_08 = bswap16(ptr->V_rim_08);
  bms_data[DEFAULT_INSTANCE].V_rim_09 = bswap16(ptr->V_rim_09);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x109 received.");
#endif

  String txt = "0x109-Battery: " + BMS_frame_109_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10A
 *
 ********************************************************************/
static String BMS_frame_10A_to_string(struct bms_data_t *data) {
  char msg[128];
  snprintf(msg, sizeof(msg), "0x10A-Battery: voltage: cell 10: %d, cell 11: %d, cell 12: %d.",
           data->V_rim_10, data->V_rim_11, data->V_rim_12);
  return msg;
}

void BMS_process_frame_10A(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_10;  // Voltage van Cell in mV
    uint16_t V_rim_11;  // Voltage van Cell in mV
    uint16_t V_rim_12;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_10 = bswap16(ptr->V_rim_10);
  bms_data[DEFAULT_INSTANCE].V_rim_11 = bswap16(ptr->V_rim_11);
  bms_data[DEFAULT_INSTANCE].V_rim_12 = bswap16(ptr->V_rim_12);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10A received.");
#endif

  String txt = "0x10A-Battery: " + BMS_frame_10A_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10B
 *
 ********************************************************************/
static String BMS_frame_10B_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 13: %d, cell 14: %d, cell 15: %d.",
           data->V_rim_13, data->V_rim_14, data->V_rim_15);
  return msg;
}

void BMS_process_frame_10B(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_13;  // Voltage van Cell in mV
    uint16_t V_rim_14;  // Voltage van Cell in mV
    uint16_t V_rim_15;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_13 = bswap16(ptr->V_rim_13);
  bms_data[DEFAULT_INSTANCE].V_rim_14 = bswap16(ptr->V_rim_14);
  bms_data[DEFAULT_INSTANCE].V_rim_15 = bswap16(ptr->V_rim_15);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10B received.");
#endif

  String txt = "0x10B-Battery: " + BMS_frame_10B_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10C
 *
 ********************************************************************/
static String BMS_frame_10C_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 16: %d, cell 17: %d, cell 18: %d.",
           data->V_rim_16, data->V_rim_17, data->V_rim_18);
  return msg;
}

void BMS_process_frame_10C(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_16;  // Voltage van Cell in mV
    uint16_t V_rim_17;  // Voltage van Cell in mV
    uint16_t V_rim_18;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_16 = bswap16(ptr->V_rim_16);
  bms_data[DEFAULT_INSTANCE].V_rim_17 = bswap16(ptr->V_rim_17);
  bms_data[DEFAULT_INSTANCE].V_rim_18 = bswap16(ptr->V_rim_18);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10C received.");
#endif

  String txt = "0x10C-Battery: " + BMS_frame_10C_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10D
 *
 ********************************************************************/
static String BMS_frame_10D_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 19: %d, cell 20: %d, cell 21: %d.",
           data->V_rim_19, data->V_rim_20, data->V_rim_21);
  return msg;
}

void BMS_process_frame_10D(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_19;  // Voltage van Cell in mV
    uint16_t V_rim_20;  // Voltage van Cell in mV
    uint16_t V_rim_21;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_19 = bswap16(ptr->V_rim_19);
  bms_data[DEFAULT_INSTANCE].V_rim_20 = bswap16(ptr->V_rim_20);
  bms_data[DEFAULT_INSTANCE].V_rim_21 = bswap16(ptr->V_rim_21);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10D received.");
#endif

  String txt = "0x10D-Battery: " + BMS_frame_10D_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10E
 *
 ********************************************************************/
static String BMS_frame_10E_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 22: %d, cell 23: %d, cell 24: %d.",
           data->V_rim_22, data->V_rim_23, data->V_rim_24);
  return msg;
}

void BMS_process_frame_10E(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_22;  // Voltage van Cell in mV
    uint16_t V_rim_23;  // Voltage van Cell in mV
    uint16_t V_rim_24;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_22 = bswap16(ptr->V_rim_22);
  bms_data[DEFAULT_INSTANCE].V_rim_23 = bswap16(ptr->V_rim_23);
  bms_data[DEFAULT_INSTANCE].V_rim_24 = bswap16(ptr->V_rim_24);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10E received.");
#endif

  String txt = "0x10E-Battery: " + BMS_frame_10E_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x10F
 *
 ********************************************************************/
static String BMS_frame_10F_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 25: %d, cell 26: %d, cell 27: %d.",
           data->V_rim_25, data->V_rim_26, data->V_rim_27);
  return msg;
}

void BMS_process_frame_10F(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_25;  // Voltage van Cell in mV
    uint16_t V_rim_26;  // Voltage van Cell in mV
    uint16_t V_rim_27;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_25 = bswap16(ptr->V_rim_25);
  bms_data[DEFAULT_INSTANCE].V_rim_26 = bswap16(ptr->V_rim_26);
  bms_data[DEFAULT_INSTANCE].V_rim_27 = bswap16(ptr->V_rim_27);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x10F received.");
#endif

  String txt = "0x10F-Battery: " + BMS_frame_10F_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x110
 *
 ********************************************************************/
static String BMS_frame_110_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Voltage: cell 28: %d, cell 29: %d, cell 30: %d.",
           data->V_rim_28, data->V_rim_29, data->V_rim_30);
  return msg;
}

void BMS_process_frame_110(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t V_rim_28;  // Voltage van Cell in mV
    uint16_t V_rim_29;  // Voltage van Cell in mV
    uint16_t V_rim_30;  // Voltage van Cell in mV
    uint16_t CRC;       // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].V_rim_28 = bswap16(ptr->V_rim_28);
  bms_data[DEFAULT_INSTANCE].V_rim_29 = bswap16(ptr->V_rim_29);
  bms_data[DEFAULT_INSTANCE].V_rim_30 = bswap16(ptr->V_rim_30);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x110 received.");
#endif

  String txt = "0x110-Battery: " + BMS_frame_110_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x355
 *
 ********************************************************************/
static String BMS_frame_355_to_string(struct bms_data_t *data) {
  char msg[128];
  snprintf(msg, sizeof(msg), "State Of Charge: %d.", data->SOC);
  return msg;
}

void BMS_process_frame_355(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t SOC;  // State of Charge waarde = uint8_t 0 = LSB , uint8_t 1 = MSB
    uint16_t CRC;  // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].SOC = bswap16(ptr->SOC);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x355 received.");
#endif

  String txt = "0x355-Battery: " + BMS_frame_355_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process frame with id=0x356
 *
 ********************************************************************/
static String BMS_frame_356_to_string(struct bms_data_t *data) {
  char msg[64];
  snprintf(msg, sizeof(msg), "Pack: voltage: %d, amapere: %d, temperature: %3.1f.",
           data->Pack_Voltage,
           data->Pack_Ampere,
           GetBMSBatteryPackTemperature());
  return msg;
}

void BMS_process_frame_356(uint8_t *buffer, int size) {
  struct data_fmt {
    uint16_t Pack_Voltage;  // in mVolt waarde = uint8_t 0 = LSB , uint8_t 1 = MSB
    uint16_t Pack_Ampere;   // in mAmp  waarde = uint8_t 2 = LSB , uint8_t 3 = MSB
    uint16_t Pack_Temp;     // in  0,1 Gr. celsius waarde = uint8_t 4 = LSB , uint8_t 5 = MSB
    uint16_t CRC;           // CRC Waarde
  };

  struct data_fmt *ptr = (struct data_fmt *)buffer;

  bms_data[DEFAULT_INSTANCE].Pack_Voltage = bswap16(ptr->Pack_Voltage);
  bms_data[DEFAULT_INSTANCE].Pack_Ampere = bswap16(ptr->Pack_Ampere);
  bms_data[DEFAULT_INSTANCE].Pack_Temp = bswap16(ptr->Pack_Temp);

#ifdef DEBUG_FRAMES
  Serial.println("BMS frame 0x356 received.");
#endif

  String txt = "0x356-Battery: " + BMS_frame_356_to_string(&bms_data[DEFAULT_INSTANCE]);
  DEBUG_frames(txt);
}

/*********************************************************************
 *  BMS process received frames
 *
 ********************************************************************/
void BMS_process_frame(uint32_t id, uint8_t *buffer, uint8_t size, bool rtr, bool ext) {
  (void)ext;
  
  BMS_frame_received();

  // Check for RTR flag (we do no read commands here)
  if (rtr)
    return;

#ifdef DEBUG_FRAMES
  char buffer[64];
  snprintf(buffer, sizeof(buffer), "BMS frame received with id 0x%04x.", frame->id);
  Serial.println(buffer);
#endif

  switch (id) {
    case 0x100:
      BMS_process_frame_100(buffer, size);
      bms_id_100_received = true;
      break;

    case 0x101:
      BMS_process_frame_101(buffer, size);
      bms_id_101_received = true;
      break;

    case 0x102:
      BMS_process_frame_102(buffer, size);
      break;

    case 0x103:
      BMS_process_frame_103(buffer, size);
      break;

    case 0x104:
      BMS_process_frame_104(buffer, size);
      break;

    case 0x105:
      BMS_process_frame_105(buffer, size);
      bms_id_105_received = true;
      break;

    case 0x106:
      BMS_process_frame_106(buffer, size);
      break;

    case 0x107:
      BMS_process_frame_107(buffer, size);
      break;

    case 0x108:
      BMS_process_frame_108(buffer, size);
      break;

    case 0x109:
      BMS_process_frame_109(buffer, size);
      break;

    case 0x10A:
      BMS_process_frame_10A(buffer, size);
      break;

    case 0x10B:
      BMS_process_frame_10B(buffer, size);
      break;

    case 0x10C:
      BMS_process_frame_10C(buffer, size);
      break;

    case 0x10D:
      BMS_process_frame_10D(buffer, size);
      break;

    case 0x10E:
      BMS_process_frame_10E(buffer, size);
      break;

    case 0x10F:
      BMS_process_frame_10F(buffer, size);
      break;

    case 0x110:
      BMS_process_frame_110(buffer, size);
      break;

    case 0x355:
      BMS_process_frame_355(buffer, size);
      break;

    case 0x356:
      BMS_process_frame_356(buffer, size);
      break;

    default:
#ifdef DEBUG_FRAMES
      Serial.println("BMS_process_frame: unknow id received, no action.");
#endif
      break;
  }
}

/*********************************************************************
 *  Request data from BMS
 *
 *  Send RTR Bericht met ID naar BMS -> reactie ID Informatie van BMS
 *  send data:  uint32_t ID, byte Ext, byte RTR,  byte Lengte,  buffer
 ********************************************************************/
void BMS_request_data(uint32_t id) {
#ifdef DEBUG_REQUESTS
  char buffer[32];
  snprintf(buffer, sizeof(buffer), "BMS request data with id 0x%04x.", id);
  Serial.println(buffer);
#endif

  MCP1_send(id, {0}, 0, true);  // With RTR
}

/*******************************************************************
 * Debug Battery Management System
 *******************************************************************/
static void BMS_debug_data(void) {
  DEBUG_data("BMS: " + BMS_frame_100_to_string());
  DEBUG_data(BMS_frame_101_to_string());
}

/*********************************************************************
 *  Millisecond timer
 ********************************************************************/
static void start_ms_timer(unsigned long &start_ms) {
  start_ms = millis();
}

static bool timeout_ms_timer(unsigned long start_ms, unsigned long timeout_ms) {
  unsigned long time_ms = millis();

  if (time_ms < start_ms)  // Wrap around after 49 days.
    start_ms = (start_ms + 0xFFFFFFFF);

  return ((time_ms - start_ms) > timeout_ms);
}

/*********************************************************************
 *  BMS request ID idle state
 ********************************************************************/
void fnStateS1() {
#ifdef DEBUG_STATEMACHINE
  Serial.println("BMS requesting idle task.");
#endif
  start_ms_timer(bms_request_starttime);
}

bool fnTransitionS1S2() {
  // After idle time, start getting data from BMS
  return timeout_ms_timer(bms_request_starttime, REQUEST_IDLE_MS);
}

/*********************************************************************
 *  BMS request ID 0x100
 ********************************************************************/
void fnStateS2() {
#ifdef DEBUG_STATEMACHINE
  Serial.println("Request ID 0x100.");
#endif
  bms_id_100_received = false;
  BMS_request_data(0x100);
  start_ms_timer(bms_request_starttime);
}

bool fnTransitionS2S3() {
  if (bms_id_100_received)
    return true;

  return timeout_ms_timer(bms_request_starttime, REQUEST_TIMEOUT_MS);
}

/*********************************************************************
 *  BMS request ID 0x101
 ********************************************************************/
void fnStateS3() {
#ifdef DEBUG_STATEMACHINE
  Serial.println("Request ID 0x101.");
#endif
  bms_id_101_received = false;
  BMS_request_data(0x101);
  start_ms_timer(bms_request_starttime);
}

bool fnTransitionS3S4() {
  if (bms_id_101_received)
    return true;

  return timeout_ms_timer(bms_request_starttime, REQUEST_TIMEOUT_MS);
}

/*********************************************************************
 *  BMS request ID 0x105
 ********************************************************************/
// BMS request data with ID 105
void fnStateS4() {
#ifdef DEBUG_STATEMACHINE
  Serial.println("Request ID 0x105.");
#endif
  bms_id_105_received = false;
  BMS_request_data(0x105);
  start_ms_timer(bms_request_starttime);
}

bool fnTransitionS4S1() {
  if (bms_id_105_received)
    return true;

  return timeout_ms_timer(bms_request_starttime, REQUEST_TIMEOUT_MS);
}

/*********************************************************************
 *  BMS main task
 *
 ********************************************************************/
void BMS_main_task(void *parameter) {
  (void)parameter;

  while (1) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
    stateMachine.Update();
  }
}

/*********************************************************************
 *  BMS monitor task
 *
 ********************************************************************/
void BMS_monitor_task(void *parameter) {
  (void)parameter;

  while (1) {
    vTaskDelay(1000 / portTICK_PERIOD_MS);

    if (bms_error_delay > 0)
      bms_error_delay--;
  }
}

/*********************************************************************
 *  BMS debug task
 *
 ********************************************************************/
void BMS_debug_task(void *parameter) {
  (void)parameter;

  while (1) {
    vTaskDelay(3000 / portTICK_PERIOD_MS);

    if (DEBUG_data_active())
      BMS_debug_data();
  }
}

/*********************************************************************
 *  Setup BMS statemachine
 ********************************************************************/
void BMS_setup_statemachine() {
  // Idle, delay requesting data
  stateMachine.AddTransition(idStateS1, idStateS2, fnTransitionS1S2);
  stateMachine.SetOnEntering(idStateS1, fnStateS1);

  // Request BMS dat with id 100
  stateMachine.AddTransition(idStateS2, idStateS3, fnTransitionS2S3);
  stateMachine.SetOnEntering(idStateS2, fnStateS2);

  // Request BMS dat with id 101
  stateMachine.AddTransition(idStateS3, idStateS4, fnTransitionS3S4);
  stateMachine.SetOnEntering(idStateS3, fnStateS3);

  // Request BMS dat with id 105
  stateMachine.AddTransition(idStateS4, idStateS1, fnTransitionS4S1);
  stateMachine.SetOnEntering(idStateS4, fnStateS4);

  // Initial state
  stateMachine.SetState(idStateS1, false, true);

#ifdef DEBUG_STATEMACHINE
  Serial.println("Setting up statemachine finsihed");
#endif
}

/*********************************************************************
 * Create initial JSON data
 ********************************************************************/
static JsonDocument BMS_json(void) {
  JsonDocument doc;

  doc[JSON_BMS_CHANNEL] = "MCP";
  doc[JSON_BMS_FLOOR_FACTOR] = bms_floor_factor;
  doc[JSON_BMS_RECEIVED] = bms_frames_received;

  // TODO: Battery data

  return doc;
}

/*********************************************************************
 * Create string
 ********************************************************************/
String BMS_string(void) {
  JsonDocument doc = BMS_json();

  String text = "--- BMS ---";

  text.concat("\r\nBMS communication channel: ");
  text.concat(doc[JSON_BMS_CHANNEL].as<const char *>());

  text.concat("\r\nFloor factor: ");
  text.concat(doc[JSON_BMS_FLOOR_FACTOR].as<float>());

  // TODO: Battery data

  text.concat("\r\n");
  return text;
}

/*********************************************************************
 * REST API: read handler
 *********************************************************************/
void BMS_rest_read(AsyncWebServerRequest *request) {
  String str;
  serializeJson(BMS_json(), str);
  request->send(200, "application/json", str.c_str());
}

static rest_api_t BMS_api_handlers = {
    /* uri */ "/api/v1/bms",
    /* comment */ "BMS module",
    /* instances */ 1,
    /* fn_create */ nullptr,
    /* fn_read */ BMS_rest_read,
    /* fn_update */ nullptr,
    /* fn_delete */ nullptr,
};

/*********************************************************************
 *  CLI: List storage content
 ********************************************************************/
static void clicb_bms_settings(cmd *c) {
  Command cmd(c);
  Argument arg = cmd.getArg(0);
  String strArg = arg.getValue();

  /* List settings */
  if (strArg.isEmpty()) {
    CLI_println(BMS_string());
    return;
  }

  /* Set NMEA Instance */
  if (strArg.equalsIgnoreCase("floor")) {
    arg = cmd.getArg(1);
    strArg = arg.getValue();
    set_floor_factor(strArg.toFloat());
    CLI_println(String("BMS floor factor set to " + String(get_floor_factor()) + "."));
    return;
  }

  CLI_println("Invalid command: BMS (floor <n>).");
}

/*********************************************************************
 *  Setup storage command handlers
 *
 ********************************************************************/
void BMS_cli_handlers(void) {
  cli.addCommand("bms", clicb_bms_settings);
}

/*********************************************************************
 * Setup MCP receive handler
 ********************************************************************/
static void BMS_setup_CAN(void) {
  MCP1_rx_handler(BMS_process_frame);
}

/*********************************************************************
 *  Setup BMS tasks
 ********************************************************************/
void BMS_setup_tasks() {
  xTaskCreate(BMS_main_task, "BMS main task", 4096, NULL, 10, NULL);
  xTaskCreate(BMS_monitor_task, "BMS monitor task", 1024, NULL, 10, NULL);
  xTaskCreate(BMS_debug_task, "BMS debug task", 2048, NULL, 15, NULL);
}

/********************************************************************
 * Setup variables
 ********************************************************************/
static void BMS_setup_variables(void) {
  /* Converter mode (BMS, DMC or SHUNT) */
  if (STORAGE_get_float(JSON_BMS_FLOOR_FACTOR, bms_floor_factor)) {
    bms_floor_factor = INITAL_FLOOR_FACTOR;
    STORAGE_set_float(JSON_BMS_FLOOR_FACTOR, bms_floor_factor);
  }
}

/*********************************************************************
 * Setup BMS
 ********************************************************************/
void BMS_setup(void) {
  BMS_setup_variables();
  BMS_cli_handlers();
  setup_uri(&BMS_api_handlers);
}

/*********************************************************************
 * Start BMS
 ********************************************************************/
void BMS_start(bool active) {
  if (active) {
    Serial.println("BMS mode active.");

    MCP1_setup(CAN_500KB);
    BMS_setup_statemachine();
    BMS_setup_tasks();
    BMS_setup_CAN();
  } 

#ifdef DEBUG_FRAMES
  Serial.println("BMS debug frames activated...");
#endif

  Serial.println("BMS setup completed...");
}
