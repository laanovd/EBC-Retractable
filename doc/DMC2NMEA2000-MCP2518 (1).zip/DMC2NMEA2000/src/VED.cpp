/*********************************************************************
 *    VED.h
 *    
 *    Victron direct
 * 
 ********************************************************************/
#include <Arduino.h>
#include <esp32-hal.h>
#include <ArduinoJson.h>
#include "WebServer.h"
#include "VeDirectFrameHandler.h"

#include "Config.h"
#include "Debug.h"
#include "Storage.h"
#include "CLI.h"
#include "NMEA.h"
#include "VED.h"

/*********************************************************************
 * Constants
 ********************************************************************/
#undef DEBUG_FRAMES                 // Debug received frames
#undef DEBUG_UNKNOWN                // Show unknown fields

#define VED_DEBUG_INTERVAL  500     // Max display rate for debug (ms)

#define SERIAL2_RX 22               // Smart Shunt Rx
#define SERIAL2_TX 21               // Smart Shunt Tx

#define DEFAULT_INSTANCE 0          //

#define INITIAL_FULL_CAPACITY 200.0 // Ah

/*********************************************************************
 * Type definitions
 ********************************************************************/
typedef struct {
  double Smart_S_Volt;      // Batterij Spanning in mV        Parameter = V in mV
  double Smart_S_Amp;       // Batterij Ampere in mA          Parameter = I in mA
  double Smart_P;           // Vermogen in milli Watt         Parameter = P in mW
  int Charge_Cycles;        // aantal ladings cycly           Parameter = H4
  int Discharge_Cycles;     // aantal vol ontladings cycly    Parameter = H5
  double Consumed_mAh;      // aantal verbruikte mAh          Parameter = CE in mA
  double State_Of_Charge;   // Hoe vol de batterijen nog zijn Parameter = SOC in 0,1 %
  double Dicharged_Energy;  // Hoeveel Energie is ontladen    Parameter = H17 in 0,01 kWh
  double Charged_Energy;    // Hoeveel Energie is geladen     Parameter = H18 in 0,01 kWh
  double Time_to_go;        // Resterende tijd voor battery   Parameter = TTG in min.
} ved_data_t;

typedef enum {
  CMD_VED_ERROR,
  CMD_VED_VOLTAGE,
  CMD_VED_AMPERAGE,
  CMD_VED_WATT,
  CMD_VED_H4,
  CMD_VED_H5,
  CMD_VED_CE,
  CMD_VED_SOC,
  CMD_VED_H17,
  CMD_VED_H18,
  CMD_VED_TTG
} ved_cmd_t;

static ved_cmd_t VED_translate_command(String cmd);

/*********************************************************************
 * Global data
 *   
 ********************************************************************/
VeDirectFrameHandler VEDirect;  // Smart Shunt Driver

static ved_data_t ved_data[1] = { 0 };

static uint32_t ved_frames_received = 0;
static int ved_error_delay = 0;

static float ved_full_capacity = INITIAL_FULL_CAPACITY;

/********************************************************************************
 * Number of VED frames received (and processed)
 ********************************************************************************/
bool VED_Frame_Received(void) {
  static int memo = 0;

  if (memo != ved_frames_received) {
    memo = ved_frames_received;
    return true;
  }
  return false;
}

/********************************************************************************
 * VED error status
 ********************************************************************************/
bool VED_error(void) {
  return (ved_error_delay == 0);
}

/********************************************************************************
 * DMC data received
 ********************************************************************************/
static void VED_data_received(void) {
  /* Increment received frames */
  ved_frames_received++;

  /* reload communication error counter */
  ved_error_delay = ERROR_RELOAD_COUNTS;
}

/*********************************************************************
 *  Get the stored battery full capacity
 *   
 ********************************************************************/
float get_intial_full_cap(void) {
  return ved_full_capacity;
}

/*********************************************************************
 *  Set the stored battery full capacity
 *   
 ********************************************************************/
void set_intial_full_cap(float value) {
  if (ved_full_capacity != value) {
    ved_full_capacity != value;
    STORAGE_set_float(JSON_VED_FULL_CAPACITY, ved_full_capacity);
  }
}

/*********************************************************************
 *  VED debug info
 ********************************************************************/
static void VED_debug_frames(String msg) {
  static unsigned long prev = 0;
  unsigned long now = millis();

  if ((msg.length() < 3) || ((millis() - prev) < VED_DEBUG_INTERVAL))
    return;
  prev = millis();

  // Format VEDirect message
  msg.replace("\t", ": ");    // Replace tabs
  msg.replace("\r\n", ", ");  // Replace Caridge Return and Linefeed

  msg = msg.substring(1, msg.length() - 1);  // Remove first comma

  msg = "VED-RX: " + msg;
  DEBUG_frames(msg);

#ifdef DEBUG_FRAMES
  Serial.println(msg.c_str());
#endif
}

/*******************************************************************
 * Get shunt voltage (V)
 *******************************************************************/
double GetSHTBatteryVoltage(void) {
  return ved_data[DEFAULT_INSTANCE].Smart_S_Volt  / 1000.0;
}

/*******************************************************************
 * Get shunt amperes (A)
 *******************************************************************/
double GetSHTBatteryCurrent(void) {
  return ved_data[DEFAULT_INSTANCE].Smart_S_Amp  / 1000.0;
}

/*******************************************************************
 * Get shunt power (W)
 *******************************************************************/
double GetSHTBatteryPower(void) {
  return ved_data[DEFAULT_INSTANCE].Smart_P  / 1000.0;
}

/*******************************************************************
 *  Get battery remaining time (double, sec.)
 *******************************************************************/
double GetSHTBatteryRemainingTime(void) {
  return ved_data[DEFAULT_INSTANCE].Time_to_go * 60.0;
}

/*******************************************************************
 * Get shunt power (W)
 *******************************************************************/
double GetSHTBatteryRemainingCapacity(void) {
  return (GetSHTBatteryChargedEnergy() - GetSHTBatteryDischargedEnergy()) * 1000.0;
}

/*******************************************************************
 * Get shunt charge cycles (count)
 *******************************************************************/
int GetSHTBatteryChargeCycles(void) {
  return ved_data[DEFAULT_INSTANCE].Charge_Cycles;
}

/*******************************************************************
 * Get shunt discharge cycles (count)
 *******************************************************************/
int GetSHTBatteryDischargeCycles(void) {
  return ved_data[DEFAULT_INSTANCE].Discharge_Cycles;
}

/*******************************************************************
 * Get shunt consumed energy (ampere)
 *******************************************************************/
double GetSHTBatteryConsumedEnergy(void) {
  return ved_data[DEFAULT_INSTANCE].Consumed_mAh / 1000.0;
}

/*******************************************************************
 * Get shunt state of charge (‰ > %)
 *******************************************************************/
uint8_t GetSHTBatteryStateOfCharge(void) {
  return ved_data[DEFAULT_INSTANCE].State_Of_Charge / 10;
}

/*******************************************************************
 * Get shunt discharged energy (kW)
 *******************************************************************/
double GetSHTBatteryDischargedEnergy(void) {
  return ved_data[DEFAULT_INSTANCE].Dicharged_Energy / 100.0;
}

/*******************************************************************
 * Get shunt charged energy (kW)
 *******************************************************************/
double GetSHTBatteryChargedEnergy(void) {
  return ved_data[DEFAULT_INSTANCE].Charged_Energy / 100.0;
}

/*********************************************************************
 *  Get battery full capacity (double, 1 decimal, Ah)
 ********************************************************************/
double GetSHTBatteryFullCapacity(void) {
  return get_intial_full_cap();
};

/*********************************************************************
 *  VED process voltage, parameter 'V', mV.
 ********************************************************************/
static void VED_save_voltage(String value) {
  ved_data[DEFAULT_INSTANCE].Smart_S_Volt = value.toFloat(); 
}

/*********************************************************************
 *  VED process current, parameter 'I', mA.
 ********************************************************************/
static void VED_save_ampere(String value) {
  ved_data[DEFAULT_INSTANCE].Smart_S_Amp = value.toFloat();  
}

/*********************************************************************
 *  VED process power, parameter 'P', milli Watt.
 ********************************************************************/
static void VED_save_watt(String value) {
  ved_data[DEFAULT_INSTANCE].Smart_P = value.toFloat();
}

/*********************************************************************
 *  VED process charge cycles, parameter 'H4', number.
 ********************************************************************/
static void VED_save_charge_cycles(String value) {
  ved_data[DEFAULT_INSTANCE].Charge_Cycles = value.toInt();
}

/*********************************************************************
 *  VED process discharge cycles, parameter 'H5', number.
 ********************************************************************/
static void VED_save_discharge_cycles(String value) {
  ved_data[DEFAULT_INSTANCE].Discharge_Cycles = value.toInt();
}

/*********************************************************************
 *  VED process used ampere since last full charge, parameter 'CE', mA.
 ********************************************************************/
static void VED_save_consumed_energy(String value) {
  ved_data[DEFAULT_INSTANCE].Consumed_mAh = value.toFloat();  
}

/*********************************************************************
 *  VED process State-Of-Charge, parameter 'SOC', promille.
 ********************************************************************/
static void VED_save_state_of_charge(String value) {
  ved_data[DEFAULT_INSTANCE].State_Of_Charge = value.toFloat();
}

/*********************************************************************
 *  VED process discharged energy, parameter 'H17', Watt.
 ********************************************************************/
static void VED_save_discharged_energy(String value) {
  ved_data[DEFAULT_INSTANCE].Dicharged_Energy = value.toFloat();
}

/*********************************************************************
 *  VED process charged energy, parameter 'H17', Watt.
 ********************************************************************/
static void VED_save_charged_energy(String value) {
  ved_data[DEFAULT_INSTANCE].Charged_Energy = value.toFloat(); 
}

/*********************************************************************
 *  VED process time to go (min.)
 ********************************************************************/
static void VED_save_time_to_go(String value) {
  float time = value.toFloat();
  // if (time > (99.99 *60.0))
  //   time = (99.99 * 60.0); // Max 99hr and 99 min.
  ved_data[DEFAULT_INSTANCE].Time_to_go = time;
}

/*******************************************************************
 * Translate field id from VEDirect to enum
 *******************************************************************/
static ved_cmd_t VED_translate_command(String cmd) {
  if (cmd.equals("V"))
    return CMD_VED_VOLTAGE;

  if (cmd.equals("I"))
    return CMD_VED_AMPERAGE;

  if (cmd.equals("P"))
    return CMD_VED_WATT;

  if (cmd.equals("H4"))
    return CMD_VED_H4;

  if (cmd.equals("H5"))
    return CMD_VED_H5;

  if (cmd.equals("CE"))
    return CMD_VED_CE;

  if (cmd.equals("SOC"))
    return CMD_VED_SOC;

  if (cmd.equals("H17"))
    return CMD_VED_H17;

  if (cmd.equals("H18"))
    return CMD_VED_H18;

  if (cmd.equals("TTG"))
    return CMD_VED_TTG;

  return CMD_VED_ERROR;  // Unknown VEDirect command
}

/*********************************************************************
 *  VED process received frames
 *   
 ********************************************************************/
static void VED_save_fields(String id, String value) {
  switch (VED_translate_command(id)) {
    case CMD_VED_VOLTAGE:
      VED_save_voltage(value);
      break;

    case CMD_VED_AMPERAGE:
      VED_save_ampere(value);
      break;

    case CMD_VED_WATT:
      VED_save_watt(value);
      break;

    case CMD_VED_H4:
      VED_save_charge_cycles(value);
      break;

    case CMD_VED_H5:
      VED_save_discharge_cycles(value);
      break;

    case CMD_VED_CE:
      VED_save_consumed_energy(value);
      break;

    case CMD_VED_SOC:
      VED_save_state_of_charge(value);
      break;

    case CMD_VED_H17:
      VED_save_discharged_energy(value);
      break;

    case CMD_VED_H18:
      VED_save_charged_energy(value);
      break;

    case CMD_VED_TTG:
      VED_save_time_to_go(value);
      break;

    case CMD_VED_ERROR:
#ifdef DEBUG_UNKNOWN
      char msg[64];
      snprintf(msg, sizeof(msg), "Unknown VEDirect field id [%s/%s].", id.c_str(), value.c_str());
      Serial.println(msg);
#endif
      break;
  }
}
/*******************************************************************
 * Debug Shunt values
 *******************************************************************/
static void SHUNT_debug_data(void) {
  char msg[128];

  snprintf(msg, sizeof(msg), "SHUNT: volt: %2.1fV, amp.: %3.1fA, power: %3.1fkW, ch.cycles: %d, disch.cycles: %d.",
           GetSHTBatteryVoltage(), 
           GetSHTBatteryCurrent(), 
           GetSHTBatteryPower(),
           GetSHTBatteryChargeCycles(), 
           GetSHTBatteryDischargeCycles());
  DEBUG_data(msg);

  snprintf(msg, sizeof(msg), "Used amp: %3.1fA, State-Of-Charge: %d%%, disch.energy: %3.2fkW, ch.energy: %3.2fkW.",
           GetSHTBatteryConsumedEnergy(), 
           (int)GetSHTBatteryStateOfCharge(),
           GetSHTBatteryDischargedEnergy()/1000.0, 
           GetSHTBatteryChargedEnergy()/1000.0);
  DEBUG_data(msg);
}

/*********************************************************************
 * Create initial JSON data
 ********************************************************************/
static JsonDocument VED_json(void) {
  JsonDocument doc;

  doc[JSON_VED_CHANNEL] = "Serial2";
  doc[JSON_VED_RECEIVED] = ved_frames_received;

    return doc;
}

/*********************************************************************
 * Create string
 ********************************************************************/
String VED_string(void) {
  JsonDocument doc = VED_json();

  String text = "--- SHUNT ---";

  text.concat("\r\nSHUNT communication channel: ");
  text.concat(doc[JSON_VED_CHANNEL].as<const char *>());

  text.concat("\r\nSHUNT received frames: ");
  text.concat(doc[JSON_VED_RECEIVED].as<int>());

  text.concat("\r\n");
  return text;
}

/*********************************************************************
 *  CLI: List storage content
 ********************************************************************/
static void clicb_list_ved(cmd *c) {
  (void)c;
  CLI_println(VED_string());
}

/*********************************************************************
 *  Setup storage command handlers
 ********************************************************************/
void VED_cli_handlers(void) {
  cli.addCommand("shunt", clicb_list_ved);
}

/*********************************************************************
 * REST API: read handler
 *********************************************************************/
void VED_rest_read(AsyncWebServerRequest *request) {
  String str;
  serializeJson(VED_json(), str);
  request->send(200, "application/json", str.c_str());
}

static rest_api_t VED_api_handlers = {
    /* uri */ "/api/v1/shunt",
    /* comment */ "BMS module",
    /* instances */ 1,
    /* fn_create */ nullptr,
    /* fn_read */ VED_rest_read,
    /* fn_update */ nullptr,
    /* fn_delete */ nullptr,
};

/*********************************************************************
 *  VE-Direct main task
 *   
 ********************************************************************/
void VED_main_task(void *parameter) {
  (void)parameter;
  String ved_msg;
  uint8_t inbyte;
  int ndx;

  while (true) {
    ved_msg = "";

    // Try to catch whole VEDirect messages at once...
    while (Serial2.available()) {
      while (Serial2.available()) {
        inbyte = Serial2.read();
        VEDirect.rxData(inbyte);
        ved_msg += char(inbyte);
      }
      vTaskDelay(3 / portTICK_PERIOD_MS);
    }

    if (ved_msg.length() > 8) {
      VED_data_received();
      VED_debug_frames(ved_msg);

      // Process received values
      for (ndx = 0; ndx < VEDirect.veEnd; ndx++) {
        VED_save_fields(VEDirect.veName[ndx], VEDirect.veValue[ndx]);
      }
    }

#ifdef DEBUG_VALUES
    VED_debug_values();
#endif

    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

/********************************************************************************
 *  VED monitor task
 ********************************************************************************/
static void VED_monitor_task(void * parameter) {
  (void) parameter;

  while (true) {
    vTaskDelay(1000 / portTICK_PERIOD_MS);

    if (ved_error_delay > 0)
      ved_error_delay--;
  }
}

/********************************************************************************
 *  VED debug task
 ********************************************************************************/
static void VED_debug_task(void * parameter) {
  (void) parameter;

  while (true) {
    vTaskDelay(3000 / portTICK_PERIOD_MS);
    
    if (DEBUG_data_active())
      SHUNT_debug_data();
  }
}

/*********************************************************************
 *  VED setup tasks
 ********************************************************************/
void VED_setup_tasks() {
  xTaskCreate(VED_main_task, "VED main task", 8192, NULL, 5, NULL);
  xTaskCreate(VED_monitor_task, "VED monitor task", 1024, NULL, 10, NULL);
  xTaskCreate(VED_debug_task, "VED debug task", 2048, NULL, 15, NULL);
}

/*********************************************************************
 *  VED setup serial port
 *   
 ********************************************************************/
void VED_setup_serial() {
  Serial2.begin(19200, SERIAL_8N1, SERIAL2_RX, SERIAL2_TX);  // T.b.v. VxDirect Smart Shunt Communicatie
  Serial2.flush();
}

/********************************************************************
 * Setup variables
 ********************************************************************/
static void VED_setup_variables(void) {
  /* Converter mode (BMS, DMC or SHUNT) */
  if (STORAGE_get_float(JSON_VED_FULL_CAPACITY, ved_full_capacity)) {
    ved_full_capacity = INITIAL_FULL_CAPACITY;
    STORAGE_set_float(JSON_VED_FULL_CAPACITY, ved_full_capacity);
  }
}

/*********************************************************************
 * Setup VE-Direct 
 ********************************************************************/
void VED_setup(void) {
  VED_setup_variables();
  VED_cli_handlers();
  setup_uri(&VED_api_handlers);
}

/*********************************************************************
 * Start VE-Direct 
 ********************************************************************/
void VED_start(bool active) {

  if (active) {
    Serial.println("SHUNT mode active.");

    VED_setup_serial();
    VED_setup_tasks();
  } 

#ifdef DEBUG_FRAMES
  Serial.println("VEDirect debug frames activated...");
#endif

  Serial.println("SHUNT setup completed...");
}
