/*********************************************************************
 *    BMS.ino
 *    
 *    BMS definitions and externals
 * 
 ********************************************************************/
#ifndef BMS_HEADER_ID
#define BSM_HEADER_ID

/*********************************************************************
 * JSON fields
 ********************************************************************/
#define JSON_BMS_CHANNEL "bms-channel"
#define JSON_BMS_FLOOR_FACTOR "floor-factor"
#define JSON_BMS_RECEIVED "frames-received"

// Getters
/*********************************************************************
 *  Get battery voltage (double, 1 decimal, V)
 ********************************************************************/
extern double GetBMSBatteryVoltage(void);

/*********************************************************************
 *  Get battery amperes (double, 1 decimal, A)
 ********************************************************************/
extern double GetBMSBatteryCurrent(void);

/*********************************************************************
 *  Get battery amperes average (double, 1 decimal, A)
 ********************************************************************/
extern double GetBMSBatteryAmperesAverage(void);

/*********************************************************************
 *  Get battery remaining capacity (double, 1 decimal, Ah)
 ********************************************************************/
extern double GetBMSBatteryRemainingCapacity(void);

/*********************************************************************
 *  Get battery remaining capacity (double, sec.)
 ********************************************************************/
extern double GetBMSBatteryRemainingTime(void);

/*********************************************************************
 *  Get battery full capacity (double, 1 decimal, Ah)
 ********************************************************************/
extern double GetBMSBatteryFullCapacity(void);

/*********************************************************************
 *  Get battery cycles (integer, cycles)
 ********************************************************************/
extern int16_t GetBMSBatteryCycles(void);

/*********************************************************************
 *  Get battery pack temperature
 ********************************************************************/
extern double GetBMSBatteryPackTemperature(void);

/*********************************************************************
 *  Get battery State Of Charge
 ********************************************************************/
extern int8_t GetBMSBatteryStateOfCharge(void);

/********************************************************************
 * BMS frames received
 *******************************************************************/
extern bool BMS_data_received(void);

/*********************************************************************
 * BMS error status
 *********************************************************************/
extern bool BMS_error(void);

/*********************************************************************
 * Start BMS
 ********************************************************************/
extern void BMS_start(bool active);

/*********************************************************************
 * Setup BMS
 ********************************************************************/
extern void BMS_setup(void);

#endif // BSM_HEADER_ID