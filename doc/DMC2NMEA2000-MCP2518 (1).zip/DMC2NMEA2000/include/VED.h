/**********************************************************************************
 *    VED.h
 *    
 *    Victron direct communication with Smart Shunt
 * 
 ********************************************************************/
#ifndef VEDIRECT_HEADER_ID
#define VEDIRECT_HEADER_ID

/*********************************************************************
 * JSON fields
 ********************************************************************/
#define JSON_VED_FULL_CAPACITY  "ved-full-capacity"
#define JSON_VED_CHANNEL "ved-channel"
#define JSON_VED_RECEIVED "frames-received"

/*********************************************************************
 * Get shunt voltage (V)
 ********************************************************************/
extern double GetSHTBatteryVoltage(void);

/*********************************************************************
 * Get shunt amperes (A)
 ********************************************************************/
extern double GetSHTBatteryCurrent(void);

/*********************************************************************
 * Get shunt power (W)
 ********************************************************************/
extern double GetSHTBatteryPower(void);

/*********************************************************************
 * Get shunt power (W)
 ********************************************************************/
extern double GetSHTBatteryRemainingCapacity(void);

/*********************************************************************
 *  Get battery remaining capacity (long, sec.)
 ********************************************************************/
extern double GetSHTBatteryRemainingTime(void);

/*********************************************************************
 * Get shunt charge cycles (count)
 ********************************************************************/
extern int GetSHTBatteryChargeCycles(void);

/*********************************************************************
 * Get shunt discharge cycles (count)
 ********************************************************************/
extern int GetSHTBatteryDischargeCycles(void);

/*********************************************************************
 * Get shunt consumed energy (ampere)
 ********************************************************************/
extern double GetSHTBatteryConsumedEnergy(void);

/*********************************************************************
 * Get shunt state of charge (percentage)
 ********************************************************************/
extern uint8_t GetSHTBatteryStateOfCharge(void);

/*********************************************************************
 * Get shunt discharged energy (kW)
 ********************************************************************/
extern double GetSHTBatteryDischargedEnergy(void);
  
/*********************************************************************
 * Get shunt charged energy (kW)
 ********************************************************************/
extern double GetSHTBatteryChargedEnergy(void);

/*********************************************************************
 *  Get battery full capacity (double, 1 decimal, Ah)
 ********************************************************************/
extern double GetSHTBatteryFullCapacity(void);

/*********************************************************************
 * VE-Direct frames received
 ********************************************************************/
extern bool VED_Frame_Received(void);

/*********************************************************************
 * VE-Direct error status
 ********************************************************************/
extern bool VED_error(void);

/*********************************************************************
 * Start VE-Direct 
 ********************************************************************/
extern void VED_start(bool active);

/*********************************************************************
 * Setup VE-Direct 
 ********************************************************************/
extern void VED_setup(void);

#endif // VEDIRECT_HEADER_ID