#  NMEA2000 used PGN table

| Used | Data                        | Format            | PGN v2.x | PGN v3.x  | Display | NMEA200 library function   |  Comment |
|------|-----------------------------|-------------------|----------|-----------|---------|----------------------------|-------------------------------------------|
|      | Motor_Speed                 | uint16_t          | 127488   | 128002    | yes/no  | SetN2kEngineParamRapid()   | 0..65535 [RPM] (PGN 128002?) |
|      | Motor_Current               | int16_t           | ?        | 128002    | no      | ?                          | -32768 .. 32768  [0,1 Amp] |
|      | Motor_Voltage               | uint8_t           | ?        | 128002    | no      | ?                          | 0..255 V |
| yes  | Battery_Voltage             | uint8_t           | 127508   | 128003    | yes/no  | SetN2kDCBatStatus()        | 0..255 V |
| yes  | Battery_Current             | int16_t           | 127508   | 128003    | yes/no  | SetN2kDCBatStatus()        | -32768 .. 32768  [0,1 Amp] |
| yes  | Actual_Torque               | int16_t           | 127489   | =         | yes     | SetN2kEngineDynamicParam() | -32768 .. 32768  [100/4096] |
|      | Actual_Speed                | int16_t           | 127233   | =         | no      | SetN2kMOBNotification()    | -32768 .. 32768  [100/4096] |
|      | Drive_status_indicator      | uint8_t           | ?        |           |         |                            | See Table 1  code 0..10 |
|      | Torque_limit_indicator      | Uint8_t           | ?        |           |         |                            | Or Motor_limit_indicator |
|      | Fault_Code                  | uint8_t           | ?        |           |         |                            | bit 0 Toggle_Security_Bit when in Canbus drive control Mode |
|      | Controller_Temperature      | uint8_t           | ?        |           |         |                            | 0..255 Gr Celsius |
|      | Motor_Temperature           | uint8_t           | ?        | 127490    | no      | ?                          | 0..255 Gr Celsius |
| ???  | BDI                         | uint8_t           | ?        |           |         |                            | 0..100 % |
|      | Fault_subcode               | uint16_t          | ?        |           |         |                            | 0..65535  Number  |
|      | Throttle                    | uint16_t          | ?        |           |         |                            | 0..4096 (0..100%)    [100/4096] |
|      | Brake_Pedal                 | uint16_t          | ?        | 128002    | no      | ?                          | 0..4096 (0..100%)    [100/4096] |
|      | Digital_Inputs              | uint8_t           | ?        |           |         |                            | Bit 0 Input1 Forward direction (Pump Pot / Switch 1 ) |
|      | Drive_battery_limit         | uint16_t          | ?        |           |         |                            | AMP 0..7000  [ 0,1 Amp] |
|      | Regen battery limit         | uint16_t          | ?        |           |         |                            | AMP 0..7000  [ 0,1 Amp] |
|      | BDI_vai_CAN                 | uint16_t          | ?        |           |         |                            | 0..1000      [0,1%] | 
| yes* | Bat_Voltage                 | uint16_t          | 127508   | 128003    | yes/no  | SetN2kDCBatStatus()        | waarde x 0,1 Volt |
| yes* | Bat_Ampere                  | uint16_t          | 127508   | 128003    | yes/no  | SetN2kDCBatStatus()        | waarde x 0,1 Amp |
|      | Bat_Remaining_Cap           | uint16_t          | ?        |           |         |                            | waarde x 0,1 Ah |
|      | Bat_Full_Cap                | uint16_t          | ?        |           |         |                            | waarde x 0,1 Ah |
|      | Bat_Cycles                  | uint16_t          | ?        |           |         |                            | Aantal Cycles |
|      | Bat_SOC                     | uint16_t          | ?        | 127491    | no      | ?                          | waarde % |
|      | Balance_C_1_16              | uint16_t          | ?        |           |         |                            | Ballance state of Cell 01 to 16 (bit 0 = cell 01 ,bit 15 = Cell 16 |
|      | Balance_C_17_33             | uint16_t          | ?        |           |         |                            | Ballance state of Cell 17 to 32 (bit 0 = cell 17 ,bit 15 = Cell 32 |
|      | Status_1_2                  | uint16_t          | ?        | 128003    | no      |                            | |
|      | Firm_version                | uint16_t          | ?        |           |         |                            | BMS firmware version |
|      | Bat_Nr                      | uint8_t           | ?        |           |         |                            | Number of batteries |
|      | NTC_Nr                      | uint8_t           | ?        |           |         |                            | Number of NTC´s |
| yes  | Temp_NTC01                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 01 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10 || 
| yes  | Temp_NTC02                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 02 |
| yes  | Temp_NTC03                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 03 |
| yes  | Temp_NTC04                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 04 conversie => (Temp_NTCxx naar float) en dan (Temp_NTCxx - 2731)/10 || 
| yes  | Temp_NTC05                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 05 |
| yes  | Temp_NTC06                  | uint16_t          | 127508   | 127491*   | yes\no  | SetN2kDCBatStatus()        | Temperature NTC 06 |
|      | V_rim_01                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_02                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_03                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_04                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_05                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_06                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_07                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_08                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_09                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_10                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_11                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_12                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_13                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_14                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_15                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_16                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_17                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_18                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_19                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_20                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_21                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_22                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_23                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_24                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_25                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_26                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_27                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_28                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_29                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | V_rim_30                    | uint16_t          | ?        |           |         |                            | Voltage van Cell in mV |
|      | Soc                         | uint16_t          | ?        | 127491    | no      | ?                          | State of Charge waarde = uint8_t 0 = LSB , uint8_t 1 = MSB  |
|      | Volt                        | uint16_t          | 127508   | =         | yes     | SetN2kDCBatStatus()        | in mVolt waarde = uint8_t 0 = LSB , uint8_t 1 = MSB  |
|      | Amp                         | uint16_t          | 127508   | =         | yes     | SetN2kDCBatStatus()        | in mAmp  waarde = uint8_t 2 = LSB , uint8_t 3 = MSB  |
|      | Accu_Temp                   | uint16_t          | 127508   | =         | yes     | SetN2kDCBatStatus()        | in  0,1 Gr. celsius waarde = uint8_t 4 = LSB , uint8_t 5 = MSB  |
