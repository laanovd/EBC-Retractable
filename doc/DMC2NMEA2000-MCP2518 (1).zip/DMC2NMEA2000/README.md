# DMC2NMEA2000
DMC to NMEA2000 data converter
